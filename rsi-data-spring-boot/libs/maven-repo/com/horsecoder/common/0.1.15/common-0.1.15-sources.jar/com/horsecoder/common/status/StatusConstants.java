package com.horsecoder.common.status;

/**
 * Author: Zhu yuhan
 * Email: zhuyuhan2333@qq.com
 * Date: 2021/8/31 15:56
 **/
public class StatusConstants {

    public static final String MESSAGE_KEY = "message";

    public static final String STATUS_KEY = "status";

    public static final String MESSAGE_DETAIL_KEY = "message-detail";

    public static final String DEFAULT_MESSAGE = "rpc error";

    public static final String DEFAULT_DECODE_MESSAGE = "rpc decode error";

    public static final String DECODE_ERROR_DECODE_MESSAGE = "rpc exception decode error";

    public static final Integer DEFAULT_CODE = 701;

    public static final String STATUS_DEFAULT_ID = "STATUS_ERROR";

    public static final String STATUS_RPC_ERROR_HEADER = "RPC-ERROR-KEY";

    public static final String CHAIN_RPC_METHOD_KEY = "RPC_METHOD";
}
