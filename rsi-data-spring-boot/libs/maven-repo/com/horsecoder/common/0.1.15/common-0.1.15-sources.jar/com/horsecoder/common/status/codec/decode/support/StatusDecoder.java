package com.horsecoder.common.status.codec.decode.support;

import com.horsecoder.common.chain.ChainContextHolder;
import com.horsecoder.common.error.Assert;
import com.horsecoder.common.status.StatusConstants;
import com.horsecoder.common.status.StatusException;
import com.horsecoder.common.status.codec.decode.StatusErrorHandler;
import com.horsecoder.common.status.codec.decode.prehandler.DecoderPreHandle;
import com.horsecoder.common.status.codec.decode.prehandler.support.StatusErrorDecoderPreHandle;
import feign.FeignException;
import feign.Response;
import feign.Util;
import feign.codec.DecodeException;
import feign.codec.Decoder;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Optional;

import static com.horsecoder.common.status.StatusConstants.STATUS_RPC_ERROR_HEADER;

/**
 * Author: Zhu yuhan
 * Email: zhuyuhan2333@qq.com
 * Date: 2021/8/30 20:27
 **/
public class StatusDecoder extends Decoder.Default {

    private StatusErrorHandler statusErrorHandler;

    private DecoderPreHandle decoderPreHandle;

    private Decoder delegate;

    private StatusDecoder() {
    }

    public StatusDecoder(Decoder delegate, StatusErrorHandler statusErrorHandler) {
        Assert.notNull(delegate, StatusConstants.STATUS_DEFAULT_ID);
        this.delegate = delegate;
        this.statusErrorHandler = statusErrorHandler;
        this.decoderPreHandle = new StatusErrorDecoderPreHandle();
    }

    /**
     * 将feign包装的response解码为真实返回值
     *
     * @param response
     * @param type
     * @return
     * @throws IOException
     * @throws DecodeException
     * @throws FeignException
     */
    @Override
    public Object decode(Response response, Type type) throws IOException, RuntimeException {

        // 检查是否为非法RPC调用
        Method method = (Method) ChainContextHolder.get(StatusConstants.CHAIN_RPC_METHOD_KEY);
        if (method == null)
            throw new StatusException(StatusConstants.DEFAULT_CODE, StatusConstants.DECODE_ERROR_DECODE_MESSAGE);

        // clear status and message
        ChainContextHolder.remove(StatusConstants.MESSAGE_KEY);
        ChainContextHolder.remove(StatusConstants.STATUS_KEY);

        // 判断是否包含异常
        // 1. 如果有异常， 走异常handler
        if (response.headers() != null && (
                !CollectionUtils.isEmpty(response.headers().get(STATUS_RPC_ERROR_HEADER)) || !CollectionUtils.isEmpty(response.headers().get(STATUS_RPC_ERROR_HEADER.toLowerCase())))) {
            this.decoderPreHandle.preHandle(response, type);
            int status = response.status();
            String statusString = ChainContextHolder.getString(StatusConstants.STATUS_KEY);
            String message = ChainContextHolder.getString(StatusConstants.MESSAGE_KEY);

            if (this.hasException(statusString, message, status)) {
                throw (RuntimeException) this.statusErrorHandler.handle(method, statusString);
            }
        }

        // 2. 正常decode，兼容spring-cloud-openfeign逻辑，走spring converter逻辑
        if (!isOptional(type)) {
            return delegate.decode(response, type);
        }
        if (response.status() == 404 || response.status() == 204) {
            return Optional.empty();
        }
        Type enclosedType = Util.resolveLastTypeParameter(type, Optional.class);
        return Optional.ofNullable(delegate.decode(response, enclosedType));
    }

    private boolean hasException(String statusString, String message, Integer responseStatus) throws IOException {
        if (StringUtils.isEmpty(statusString) || StringUtils.isEmpty(message)) {
            return false;
        }
        // 判断是否发生异常，1. 状态码为错误状态码；2. message中含异常信息
        if (responseStatus >= 300 || Integer.parseInt(statusString) >= 300 || message.contains("StatusException")) {
            return true;
        }
        return false;

    }

    static boolean isOptional(Type type) {
        if (!(type instanceof ParameterizedType)) {
            return false;
        }
        ParameterizedType parameterizedType = (ParameterizedType) type;
        return parameterizedType.getRawType().equals(Optional.class);
    }
}
