package com.horsecoder.common.chain.processor;

import com.horsecoder.common.chain.ChainContextHolder;
import org.springframework.util.StringUtils;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-08-23 16:42:32
 */
public class DefaultChainKeyProcessor extends BaseChainKeyProcessor {

    @Override
    public ChainKeyEnum chainKey() {
        return null;
    }

    @Override
    public void init() {

    }

    @Override
    public void handle(String key, Object value) {
        if (StringUtils.isEmpty(value)) return;
        ChainContextHolder.put(key, value);
    }


}
