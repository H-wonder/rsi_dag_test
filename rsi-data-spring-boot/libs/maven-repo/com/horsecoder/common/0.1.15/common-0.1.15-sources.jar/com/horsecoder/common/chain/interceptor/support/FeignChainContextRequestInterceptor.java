package com.horsecoder.common.chain.interceptor.support;

import com.horsecoder.common.chain.ChainContextHolder;
import com.horsecoder.common.chain.interceptor.BaseChainContextRequestInterceptor;
import com.horsecoder.common.chain.parser.ChainKeyParser;
import com.horsecoder.common.chain.parser.map.UserGenericMap;
import com.horsecoder.common.chain.parser.metadata.ChainKeyParserMetadata;
import com.horsecoder.common.chain.parser.metadata.GenericChainKeyParserMetadata;
import com.horsecoder.common.chain.processor.ChainKeyEnum;
import feign.RequestInterceptor;
import feign.RequestTemplate;

/**
 * 适配feign
 * <p>
 * Author: Zhu yuhan
 * Email: zhuyuhan2333@qq.com
 * Date: 2020/12/4 21:00
 **/
public abstract class FeignChainContextRequestInterceptor extends BaseChainContextRequestInterceptor implements RequestInterceptor {

    @Override
    public void apply(RequestTemplate requestTemplate) {
        applyChainContextPreProcess();
        this.applyChainContext(requestTemplate);
    }

    private void applyChainContext(RequestTemplate requestTemplate) {
        for (String chainKey : ChainContextHolder.get().keySet()) {
            if (ChainKeyEnum.isChainKey(chainKey)) {
                Object chain = ChainContextHolder.get(chainKey);
                //TODO  1.出现类继承时如何匹配 例： Map -> HashMap
                //TODO  2.泛型如何匹配 例： Map<K,V> -> Map<K,V> parser 已解决，自定义UserGenericMap类型
                //首先判断是否为UserGenericMap类型
                ChainKeyParser chainKeyParser;
                Class<?> chainClass = chain.getClass();
                if (UserGenericMap.class.isAssignableFrom(chainClass)) {
                    UserGenericMap userGenericMap = (UserGenericMap) chain;
                    chainKeyParser = GenericChainKeyParserMetadata.getChainKeyParser(
                            new GenericChainKeyParserMetadata.GenericMetadata(
                                    userGenericMap.getK(), userGenericMap.getV()
                            )
                    );
                } else {
                    chainKeyParser = ChainKeyParserMetadata.getChainKeyParser(chainClass);
                }
                requestTemplate.header(chainKey, chainKeyParser.encodeChainContext(chain));
            }
        }
    }

}
