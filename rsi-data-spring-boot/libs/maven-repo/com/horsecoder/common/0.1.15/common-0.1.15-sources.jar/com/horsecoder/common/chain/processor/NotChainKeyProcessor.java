package com.horsecoder.common.chain.processor;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-08-23 16:42:32
 */
public class NotChainKeyProcessor implements ChainKeyProcessor {

    @Override
    public ChainKeyEnum chainKey() {
        return null;
    }

    @Override
    public String parserMapTag() {
        return null;
    }

    @Override
    public void init() {

    }

    @Override
    public void handle(String key, String value) {

    }
}
