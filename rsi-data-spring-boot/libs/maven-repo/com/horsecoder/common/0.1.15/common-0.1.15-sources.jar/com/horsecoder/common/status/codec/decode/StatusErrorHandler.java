package com.horsecoder.common.status.codec.decode;

import java.lang.reflect.Method;

/**
 * Author: Zhu yuhan
 * Email: zhuyuhan2333@qq.com
 * Date: 2021/9/1 20:53
 **/
public interface StatusErrorHandler {

    /**
     * 处理指定method指定status的逻辑
     *
     * @param method
     * @param status
     * @return
     */
    Exception handle(Method method, String status);

}
