package com.horsecoder.common.chain.proxy;

import com.horsecoder.common.chain.ChainContextHolder;
import com.horsecoder.common.status.StatusConstants;
import com.horsecoder.common.status.util.StatusAopTargetUtils;
import feign.Target;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.aop.Pointcut;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.framework.autoproxy.AbstractBeanFactoryAwareAdvisingPostProcessor;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.aop.support.annotation.AnnotationMatchingPointcut;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.SmartFactoryBean;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.core.Ordered;
import org.springframework.util.ClassUtils;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

/**
 * Author: Zhu yuhan
 * Email: zhuyuhan2333@qq.com
 * Date: 2021/12/12 8:49 下午
 **/
public class ChainAnnotationAdvisor extends AbstractBeanFactoryAwareAdvisingPostProcessor
        implements InitializingBean, Ordered {

    private Class<? extends Annotation> chainAnnotationType = FeignClient.class;

    private static boolean mockEnabled;

    @Override
    public void afterPropertiesSet() {
        Pointcut pointcut = new AnnotationMatchingPointcut(this.chainAnnotationType, true);
        this.advisor = new DefaultPointcutAdvisor(pointcut, new MethodInterceptor() {
            @Override
            public Object invoke(MethodInvocation invocation) throws Throwable {
                if (isFactoryBeanMetadataMethod(invocation.getMethod())) {
                    return invocation.proceed();
                }
                Target.HardCodedTarget hardCodedTarget;
                try {
                    // 运行时获取当前feign接口方法
                    hardCodedTarget = (Target.HardCodedTarget) StatusAopTargetUtils.getTarget(invocation.getThis());
                    if (hardCodedTarget == null) return invocation.proceed();
                } catch (Exception e) {
                    return invocation.proceed();
                }
                if (mockEnabled) {
                    // TODO: 2021/12/13 如果开启Mock，走Mock逻辑
                    return null;
                }
                ChainContextHolder.put(StatusConstants.CHAIN_RPC_METHOD_KEY, invocation.getMethod());
                return invocation.proceed();
            }
        });
    }

    public static void setMockEnabled(boolean mockEnabled) {
        ChainAnnotationAdvisor.mockEnabled = mockEnabled;
    }

    @Override
    public int getOrder() {
        return Ordered.LOWEST_PRECEDENCE;
    }

    private boolean isFactoryBeanMetadataMethod(Method method) {
        Class<?> clazz = method.getDeclaringClass();

        // Call from interface-based proxy handle, allowing for an efficient check?
        if (clazz.isInterface()) {
            return ((clazz == FactoryBean.class || clazz == SmartFactoryBean.class) &&
                    !method.getName().equals("getObject"));
        }

        // Call from CGLIB proxy handle, potentially implementing a FactoryBean method?
        Class<?> factoryBeanType = null;
        if (SmartFactoryBean.class.isAssignableFrom(clazz)) {
            factoryBeanType = SmartFactoryBean.class;
        } else if (FactoryBean.class.isAssignableFrom(clazz)) {
            factoryBeanType = FactoryBean.class;
        }
        return (factoryBeanType != null && !method.getName().equals("getObject") &&
                ClassUtils.hasMethod(factoryBeanType, method.getName(), method.getParameterTypes()));
    }

    @Override
    protected ProxyFactory prepareProxyFactory(Object bean, String beanName) {
        ProxyFactory proxyFactory = super.prepareProxyFactory(bean, beanName);
        proxyFactory.setProxyTargetClass(true);
        return proxyFactory;
    }
}
