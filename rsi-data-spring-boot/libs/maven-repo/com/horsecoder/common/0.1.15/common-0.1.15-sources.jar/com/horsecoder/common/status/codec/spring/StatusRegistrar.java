package com.horsecoder.common.status.codec.spring;

import com.horsecoder.common.status.codec.decode.ErrorHandler;
import com.horsecoder.common.status.codec.decode.ErrorInstance;
import com.horsecoder.common.status.codec.decode.support.StatusErrorDecoder;
import com.horsecoder.common.status.util.StatusAopTargetUtils;
import feign.Target;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.web.bind.annotation.*;

import java.lang.reflect.Method;
import java.util.Collections;

/**
 * Author: Zhu yuhan
 * Email: zhuyuhan2333@qq.com
 * Date: 2021/9/1 12:59
 **/
public class StatusRegistrar implements BeanPostProcessor {

    private static final Logger LOGGER = LoggerFactory.getLogger(StatusRegistrar.class);

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        Object target = StatusAopTargetUtils.getTarget(bean);
        if (target == null || target == bean) return bean;
        if (target instanceof Target.HardCodedTarget) {
            Target.HardCodedTarget hardCodedTarget = (Target.HardCodedTarget) target;
            try {
                StatusAopTargetUtils.putTarget(StatusAopTargetUtils.getSpringJdkDynamicProxyTargetObject(bean), hardCodedTarget);
            } catch (Exception e) {
                try {
                    StatusAopTargetUtils.putTarget(StatusAopTargetUtils.getNativeJdkDynamicProxyTargetObject(bean), hardCodedTarget);
                } catch (Exception ex) {
                    try {
                        StatusAopTargetUtils.putTarget(StatusAopTargetUtils.getCglibProxyTargetObject(bean), hardCodedTarget);
                    } catch (Exception exc) {
                        LOGGER.error("register bean:{} failed with beanName:{}", bean, beanName);
                    }
                }
            }

            //collect status error handler data
            registerStatusErrorHandlerMetadata(hardCodedTarget);
        }
        return bean;
    }

    private void registerStatusErrorHandlerMetadata(Target.HardCodedTarget hardCodedTarget) {
        Class<?> type = hardCodedTarget.type();
        if (type.isAnnotationPresent(ErrorHandler.class)) {
            ErrorHandler errorHandler = type.getAnnotation(ErrorHandler.class);
            this.parseErrorHandler(type, errorHandler);
        }
        // method has higher level
        for (Method method : type.getMethods()) {
            if (isMethodMappingAnnotated(method) && method.isAnnotationPresent(ErrorHandler.class)) {
                this.parseErrorHandler(method, method.getAnnotation(ErrorHandler.class));
            }
        }
    }

    private void parseErrorHandler(Method method, ErrorHandler errorHandler) {
        if (errorHandler == null) return;
        ErrorInstance[] errorInstances = errorHandler.instances();
        if (errorInstances == null || errorInstances.length == 0) return;
        for (ErrorInstance errorInstance : errorInstances) {
            this.parseErrorInstance(method, errorInstance);
        }
    }

    private void parseErrorHandler(Class clazz, ErrorHandler errorHandler) {
        if (errorHandler == null) return;
        ErrorInstance[] errorInstances = errorHandler.instances();
        for (ErrorInstance errorInstance : errorInstances) {
            this.parseErrorInstance(clazz, errorInstance);
        }
    }

    private void parseErrorInstance(Method method, ErrorInstance errorInstance) {
        if (errorInstance == null) return;
        StatusErrorDecoder.addMethodToExceptionsMap(method, Collections.singletonList(errorInstance));
    }

    private void parseErrorInstance(Class clazz, ErrorInstance errorInstance) {
        if (errorInstance == null) return;
        for (Method method : clazz.getMethods()) {
            StatusErrorDecoder.addMethodToExceptionsMap(method, Collections.singletonList(errorInstance));
        }
    }

    private boolean isMethodMappingAnnotated(Method method) {
        return method.isAnnotationPresent(RequestMapping.class) || method.isAnnotationPresent(PostMapping.class)
                || method.isAnnotationPresent(GetMapping.class) || method.isAnnotationPresent(PutMapping.class)
                || method.isAnnotationPresent(DeleteMapping.class) || method.isAnnotationPresent(PatchMapping.class);
    }

}
