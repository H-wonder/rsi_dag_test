package com.horsecoder.common.status.codec.decode.support;

import com.google.gson.Gson;
import com.horsecoder.common.chain.ChainContextHolder;
import com.horsecoder.common.status.Status;
import com.horsecoder.common.status.StatusConstants;
import com.horsecoder.common.status.StatusException;
import com.horsecoder.common.status.codec.decode.ErrorInstance;
import com.horsecoder.common.status.codec.decode.StatusErrorHandler;
import com.alibaba.fastjson.JSON;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

/**
 * Author: Zhu yuhan
 * Email: zhuyuhan2333@qq.com
 * Date: 2021/9/1 20:54
 **/
public class DefaultStatusErrorHandler implements StatusErrorHandler {

    @Override
    public Exception handle(Method method, String status) {
        ErrorInstance errorInstance = getErrorInstance(method, status);
        if (errorInstance == null) {
            StatusException statusException;
            String chainContextMessage = ChainContextHolder.getString(StatusConstants.MESSAGE_KEY);
            Gson gson = new Gson();
            try {
                // parse status inner exception
                statusException = gson.fromJson(chainContextMessage, StatusException.class);
                statusException.setSetResponseStatus(true);
            } catch (Exception exception) {
                try {
                    statusException = gson.fromJson(chainContextMessage.substring(15), StatusException.class);
                    statusException.setSetResponseStatus(true);
                } catch (Exception inner) {
                    return new StatusException(this.validStatusCode(status) ?
                            Integer.parseInt(status) : StatusConstants.DEFAULT_CODE,
                            chainContextMessage == null ? StatusConstants.DEFAULT_MESSAGE : chainContextMessage);
                }
            }
            return statusException;
        }
        Class<? extends Exception> exceptionClass = errorInstance.decodeException();
        int statusCode = errorInstance.statusCode();
        String message = errorInstance.message();
        Exception exception = null;
        String exceptionMessage = JSON.toJSONString(Status.builder().addStatus(statusCode)
                .addMessage(message)
                .map());
        try {
            exception = exceptionClass.getDeclaredConstructor(String.class).newInstance(exceptionMessage);
        } catch (Exception e) {
            // no op
        }
        if (StatusException.class.isAssignableFrom(exceptionClass)) {
            StatusException statusException = (StatusException) exception;
            statusException.setCode(statusCode);
            statusException.setMessage(message);
            return statusException;
        }
        return exception;
    }

    private ErrorInstance getErrorInstance(Method method, String statusString) {
        int status;
        try {
            status = Integer.parseInt(statusString);
        } catch (Exception e) {
            return null;
        }
        Map<Method, List<ErrorInstance>> methodToExceptionsMap = StatusErrorDecoder.getMethodToExceptionsMap();
        if (!CollectionUtils.isEmpty(methodToExceptionsMap)) {
            List<ErrorInstance> errorInstances = methodToExceptionsMap.get(method);
            if (CollectionUtils.isEmpty(errorInstances)) return null;
            for (ErrorInstance errorInstance : errorInstances) {
                if (errorInstance.statusCode() == status) {
                    return errorInstance;
                }
            }
        }
        return null;
    }

    private boolean validStatusCode(String status) {
        if (StringUtils.isEmpty(status)) return false;
        int code = Integer.parseInt(status);
        if (code >= 200 && code < 300) return false;
        return true;
    }
}
