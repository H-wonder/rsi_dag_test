package com.horsecoder.common.status.codec.decode.support;

import com.horsecoder.common.chain.ChainContextHolder;
import com.horsecoder.common.chain.processor.ChainKeyEnum;
import com.horsecoder.common.status.StatusConstants;
import com.horsecoder.common.status.StatusException;
import com.horsecoder.common.status.codec.decode.ErrorInstance;
import com.horsecoder.common.status.codec.decode.StatusErrorHandler;
import com.horsecoder.common.status.codec.decode.prehandler.DecoderPreHandle;
import com.horsecoder.common.status.codec.decode.prehandler.support.StatusErrorDecoderPreHandle;
import feign.Response;
import feign.codec.ErrorDecoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import java.lang.reflect.Method;
import java.util.*;

/**
 * Author: Zhu yuhan
 * Email: zhuyuhan2333@qq.com
 * Date: 2021/8/31 19:07
 **/
public class StatusErrorDecoder implements ErrorDecoder {

    private static Logger logger = LoggerFactory.getLogger(StatusErrorDecoder.class);

    private static Map<String, ErrorInstance> errorKeyToExceptionMap = new HashMap<>(64);

    /**
     * 方法:异常处理
     */
    private static Map<Method, List<ErrorInstance>> methodToExceptionsMap = new HashMap<>(64);

    /**
     * 方法名:方法
     */
    private static Map<String, Method> invokeKeyToMethodMap = new HashMap<>(64);

    private StatusErrorHandler statusErrorHandler;

    private DecoderPreHandle decoderPreHandle;

    private StatusErrorDecoder() {
    }

    public StatusErrorDecoder(StatusErrorHandler statusErrorHandler) {
        this.statusErrorHandler = statusErrorHandler;
        this.decoderPreHandle = new StatusErrorDecoderPreHandle();
    }

    /**
     * 跨服务异常捕获、解析和重抛，替换默认的feign异常处理
     *
     * @param errorMethod
     * @param response
     * @return
     */
    @Override
    public Exception decode(String errorMethod, Response response) {
        Method method = (Method) ChainContextHolder.get(StatusConstants.CHAIN_RPC_METHOD_KEY);
        if (method == null)
            throw new StatusException(StatusConstants.DEFAULT_CODE, StatusConstants.DECODE_ERROR_DECODE_MESSAGE);

        this.decoderPreHandle.preHandle(response, Map.class);
        logger.error(this.getErrorDecodeDetailLog(errorMethod, response));

        return statusErrorHandler.handle(method, ChainContextHolder.getString(StatusConstants.STATUS_KEY));
    }

    public static void addStatusMetadata(String errorKey, ErrorInstance errorInstance) {
        errorKeyToExceptionMap.put(errorKey, errorInstance);
    }

    public static void addStatusMetadata(String invokeKey, Method method) {
        invokeKeyToMethodMap.put(invokeKey, method);
    }

    public static Map<String, Method> getInvokeKeyToMethodMap() {
        return invokeKeyToMethodMap;
    }

    public static Map<String, ErrorInstance> getErrorKeyToExceptionMap() {
        return errorKeyToExceptionMap;
    }

    public static Map<Method, List<ErrorInstance>> getMethodToExceptionsMap() {
        return methodToExceptionsMap;
    }

    public static void addMethodToExceptionsMap(Method method, List<ErrorInstance> errorInstances) {
        List<ErrorInstance> sourceList = methodToExceptionsMap.get(method);
        if (CollectionUtils.isEmpty(sourceList)) {
            methodToExceptionsMap.put(method, errorInstances);
        } else {
            List<ErrorInstance> combineResult = new ArrayList<>();
            for (ErrorInstance source : sourceList) {
                int sourceCode = source.statusCode();
                boolean isDuplicate = false;
                for (ErrorInstance instance : errorInstances) {
                    if (instance.statusCode() == sourceCode) {
                        isDuplicate = true;
                        break;
                    }
                }
                if (!isDuplicate) combineResult.add(source);
            }
            combineResult.addAll(errorInstances);
            methodToExceptionsMap.put(method, combineResult);
        }
    }

    private String getErrorDecodeDetailLog(String errorMethod, Response response) {
        StringBuilder exceptionDetail = new StringBuilder();
        Map<String, Collection<String>> headers = response.headers();
        headers.forEach((header, values) -> {
            if (ChainKeyEnum.isChainKey(header.toUpperCase())) {
                Collection<String> collection = headers.get(header);
                String value = (String) ((List) collection).get(0);
                exceptionDetail.append(header.toUpperCase())
                        .append("-")
                        .append(value)
                        .append("::");
            }
        });
        return exceptionDetail.append("ERROR_METHOD-")
                .append(errorMethod)
                .toString();
    }

}
