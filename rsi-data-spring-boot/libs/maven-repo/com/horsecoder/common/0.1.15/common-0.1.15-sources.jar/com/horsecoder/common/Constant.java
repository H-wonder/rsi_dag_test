package com.horsecoder.common;

/**
 * Author: Zhu yuhan
 * Email: zhuyuhan2333@qq.com
 * Date: 2021/11/16 11:53 上午
 **/
public class Constant {

    public static final String CHAIN_START_HEADER = "CHAIN-START";

}