package com.horsecoder.common.status.util;

import feign.Target;
import org.springframework.aop.framework.AdvisedSupport;
import org.springframework.util.ClassUtils;

import java.lang.reflect.Field;
import java.lang.reflect.Proxy;
import java.util.HashMap;
import java.util.Map;

/**
 * Author: Zhu yuhan
 * Email: zhuyuhan2333@qq.com
 * Date: 2021/9/9 12:02
 **/
public class StatusAopTargetUtils {

    private static final Map<Object, Target.HardCodedTarget> targetCacheMap = new HashMap<>(16);

    public static Object getTarget(Object proxy) {
        Object target = getTargetByCache(proxy);
        if (target != null) return target;
        try {
            if (Proxy.isProxyClass(proxy.getClass())) {
                try {
                    target = getNativeJdkDynamicProxyTargetObject(proxy);
                } catch (Exception e) {
                    target = getSpringJdkDynamicProxyTargetObject(proxy);
                }
            } else if (ClassUtils.isCglibProxyClass(proxy.getClass())) {
                target = getCglibProxyTargetObject(proxy);
            } else return proxy;
            Object targetInner = getTarget(target);
            if (targetInner == null || targetInner == target) {
                return target;
            }
            return targetInner;
        } catch (Exception e) {
            return null;
        }
    }

    public static Object getCglibProxyTargetObject(Object proxy) throws Exception {
        Field f = proxy.getClass().getDeclaredField("CGLIB$CALLBACK_0");
        f.setAccessible(true);
        Object dynamicAdvisedInterceptor = f.get(proxy);

        Field advised = dynamicAdvisedInterceptor.getClass().getDeclaredField("advised");
        advised.setAccessible(true);

        Object target = ((AdvisedSupport) advised.get(dynamicAdvisedInterceptor)).getTargetSource().getTarget();
        return target;
    }


    public static Object getNativeJdkDynamicProxyTargetObject(Object proxy) throws Exception {
        Field h = proxy.getClass().getSuperclass().getDeclaredField("h");
        h.setAccessible(true);
        Object hValue = h.get(proxy);

        Field targetField = hValue.getClass().getDeclaredField("target");
        targetField.setAccessible(true);
        Object target = targetField.get(hValue);

        return target;
    }

    public static Object getSpringJdkDynamicProxyTargetObject(Object proxy) throws Exception {
        Field h = proxy.getClass().getSuperclass().getDeclaredField("h");
        h.setAccessible(true);
        Object hValue = h.get(proxy);

        Field advised = hValue.getClass().getDeclaredField("advised");
        advised.setAccessible(true);
        Object target = ((AdvisedSupport) advised.get(hValue)).getTargetSource().getTarget();

        return target;
    }

    public static void putTarget(Object proxy, Target.HardCodedTarget target) {
        targetCacheMap.put(proxy, target);
    }

    public static Target.HardCodedTarget getTargetByCache(Object proxy) {
        return targetCacheMap.get(proxy);
    }

}
