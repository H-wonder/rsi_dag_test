package com.horsecoder.common.status.codec.decode.prehandler.support;

import com.horsecoder.common.chain.ChainContextHolder;
import com.horsecoder.common.status.StatusConstants;
import com.horsecoder.common.status.StatusException;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import feign.Response;
import feign.Util;
import org.springframework.util.StringUtils;

import java.io.Reader;
import java.lang.reflect.Type;
import java.util.Map;

/**
 * Author: Zhu yuhan
 * Email: zhuyuhan2333@qq.com
 * Date: 2021/9/2 20:27
 **/
public class StatusDecoderPreHandle extends StatusBasePreHandle {

    @Override
    public void check(Response response) {
        if (response == null || response.body() == null)
            throw new StatusException(StatusConstants.DEFAULT_CODE, StatusConstants.DEFAULT_DECODE_MESSAGE);
    }

    @Override
    public void handleResponseBodyOptional(Response response, Type type) {
        Response.Body body = response.body();
        String responseMap = null;
        JSONObject responseMapJson = null;
        try {
            Reader reader = body.asReader();
            responseMap = Util.toString(reader);
            responseMapJson = JSON.parseObject(responseMap);
            if (responseMapJson == null) return;

            String statusString = responseMapJson.getString(StatusConstants.STATUS_KEY);
            String message = responseMapJson.getString(StatusConstants.MESSAGE_KEY);
            if (StringUtils.isEmpty(statusString) || StringUtils.isEmpty(message)) return;
            ChainContextHolder.put(StatusConstants.STATUS_KEY, statusString);
            ChainContextHolder.put(StatusConstants.MESSAGE_KEY, message);
        } catch (Exception e) {
            // no exception
            // clear status and message if exist because of no servlet thread
            ChainContextHolder.remove(StatusConstants.STATUS_KEY);
            ChainContextHolder.remove(StatusConstants.MESSAGE_KEY);
        }
    }
}
