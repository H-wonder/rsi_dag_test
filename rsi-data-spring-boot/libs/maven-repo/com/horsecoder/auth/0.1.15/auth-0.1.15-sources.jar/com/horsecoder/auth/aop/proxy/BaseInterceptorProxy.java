package com.horsecoder.auth.aop.proxy;


import com.horsecoder.auth.AuthConstant;
import com.horsecoder.auth.Logical;
import com.horsecoder.auth.aop.interceptor.MethodInterceptor;
import com.horsecoder.auth.aop.resource.support.AuthFlowRetriever;
import com.horsecoder.auth.authenticator.AuthenticatorHolder;
import com.horsecoder.auth.util.AuthUtils;
import com.horsecoder.common.chain.ChainContextHolder;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-08-14 21:57:27
 */
public abstract class BaseInterceptorProxy implements MethodInterceptor {

    private ThreadLocal<Collection<MethodInterceptor>> methodInterceptors = null;

    @Override
    public Object invoke(MethodInvocation methodInvocation) throws Throwable {
        this.assertAuthorized(methodInvocation);
        this.release();
        return methodInvocation.proceed();
    }

    @Override
    public void assertAuthorized(MethodInvocation methodInvocation) throws Exception {
        if (CollectionUtils.isEmpty(methodInterceptors.get())) return;

        for (MethodInterceptor interceptor : methodInterceptors.get()) {
            if (interceptor.supports(methodInvocation)) {
                interceptor.assertAuthorized(methodInvocation);
            }
        }

    }

    @Override
    public boolean supports(MethodInvocation methodInvocation) {
        return true;
    }

    @Override
    public Logical getLogical() {
        return Logical.AND;
    }

    protected void addMethodInterceptors(MethodInterceptor... methodInterceptors) {
        this.methodInterceptors = ThreadLocal.withInitial(ArrayList::new);
        this.methodInterceptors.get().addAll(Arrays.asList(methodInterceptors));
    }

    protected void clearMethodInterceptors() {
        this.methodInterceptors.remove();
    }

    private void release() {
        clearMethodInterceptors();
        AuthenticatorHolder.clear();
        ChainContextHolder.remove(AuthConstant.REQUEST_BODY_KEY);
        ChainContextHolder.remove(AuthConstant.AUTH_FLOW_MAP_KEY);
        AuthUtils.releaseAuthFlowEngine();
    }

}

