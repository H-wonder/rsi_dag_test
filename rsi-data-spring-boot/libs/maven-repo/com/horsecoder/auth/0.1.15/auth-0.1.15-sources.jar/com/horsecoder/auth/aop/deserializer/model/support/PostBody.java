package com.horsecoder.auth.aop.deserializer.model.support;

import com.horsecoder.auth.aop.deserializer.model.Body;

/**
 * Author: Zhu yuhan
 * Email: zhuyuhan2333@qq.com
 * Date: 2021/11/18 7:09 下午
 **/
public class PostBody extends Body<Object> {

    public PostBody(Object o, Class tClass) {
        super(o, tClass);
    }
}
