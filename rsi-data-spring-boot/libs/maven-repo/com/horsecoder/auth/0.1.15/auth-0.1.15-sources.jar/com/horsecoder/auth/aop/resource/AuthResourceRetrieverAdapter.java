package com.horsecoder.auth.aop.resource;

import cc.eamon.open.flow.core.context.FlowContextHolder;
import com.horsecoder.auth.AuthConstant;
import com.horsecoder.auth.util.AuthUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * Author: Zhu yuhan
 * Email: zhuyuhan2333@qq.com
 * Date: 2021/11/20 2:08 下午
 **/
public abstract class AuthResourceRetrieverAdapter implements ResourceRetriever, ResourceReserver {

    protected boolean reserve;

    protected String reserveName;

    @Override
    public boolean retrieve(String expression, String reserveName, HttpServletRequest request, boolean reserve, AuthCallback callback) {
        this.reserve = reserve;
        this.reserveName = reserveName;
        return retrieve(expression, request) && withCallback(request, callback);
    }

    public abstract boolean retrieve(String expression, HttpServletRequest request);

    @SuppressWarnings("unchecked")
    @Override
    public void reserve(String key, Object value) {
        if (!reserve) return;
        if (!StringUtils.isEmpty(reserveName)) key = reserveName;
        Map<String, Object> authContextMap = AuthUtils.getAuthContextMap();
        authContextMap.put(key, value);
    }

    private boolean withCallback(HttpServletRequest request, AuthCallback callback) {
        Map<String, Object> authContextMap = AuthUtils.getAuthContextMap();
        return callback == null || callback.auth(request, request.getRequestURI(), authContextMap);
    }
}
