package com.horsecoder.auth.aop.resource.support;

import com.horsecoder.auth.AuthConstant;
import com.horsecoder.auth.aop.deserializer.model.Body;
import com.horsecoder.auth.aop.resource.AuthResourceRetrieverAdapter;
import com.horsecoder.auth.aop.resource.ResourceRetrieveType;
import com.horsecoder.auth.authenticator.Authenticator;
import com.horsecoder.auth.authenticator.AuthenticatorHolder;
import com.horsecoder.common.chain.ChainContextHolder;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Author: Zhu yuhan
 * Email: zhuyuhan2333@qq.com
 * Date: 2021/11/19 7:07 下午
 **/
public class AuthGroupRetriever extends AuthResourceRetrieverAdapter {

    private Authenticator authenticator;

    public AuthGroupRetriever() {
        this.authenticator = AuthenticatorHolder.get();
    }

    @Override
    public boolean retrieve(String group, HttpServletRequest request) {
        HttpServletResponse response = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getResponse();
        if (!this.authenticator.open(request, response)) return true;
        String uri = request.getRequestURI();
        Body body = (Body) ChainContextHolder.get(AuthConstant.REQUEST_BODY_KEY);
        try {
            return authenticator.checkGroup(request, response, uri, group, body);
        } catch (Exception e) {
            return authenticator.checkGroup(request, response, uri, group, body);
        }
    }

    @Override
    public ResourceRetrieveType type() {
        return ResourceRetrieveType.GROUP;
    }
}
