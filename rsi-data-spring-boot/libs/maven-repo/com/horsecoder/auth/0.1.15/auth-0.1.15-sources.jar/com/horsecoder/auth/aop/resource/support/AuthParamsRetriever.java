package com.horsecoder.auth.aop.resource.support;

import cc.eamon.open.flow.core.FlowEngine;
import com.horsecoder.auth.AuthConstant;
import com.horsecoder.auth.aop.deserializer.model.Body;
import com.horsecoder.auth.aop.resource.AuthCallback;
import com.horsecoder.auth.aop.resource.AuthResourceRetrieverAdapter;
import com.horsecoder.auth.aop.resource.ResourceRetrieveType;
import com.horsecoder.auth.aop.resource.ResourceRetriever;
import com.horsecoder.auth.authenticator.Authenticator;
import com.horsecoder.auth.authenticator.AuthenticatorHolder;
import com.horsecoder.auth.util.AuthUtils;
import com.horsecoder.common.chain.ChainContextHolder;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Author: Zhu yuhan
 * Email: zhuyuhan2333@qq.com
 * Date: 2021/11/19 7:07 下午
 **/
public class AuthParamsRetriever implements ResourceRetriever {

    @Override
    public boolean retrieve(String value, String reserveName, HttpServletRequest request, boolean reserve, AuthCallback callback) {
        FlowEngine flowEngine = AuthUtils.getAuthFlowEngine();
        flowEngine.register(AuthConstant.AUTH_FLOW_SCOPE, reserveName, value);
        return true;
    }

    @Override
    public ResourceRetrieveType type() {
        return ResourceRetrieveType.PARAMS;
    }
}
