package com.horsecoder.auth.aop.resource.support;

import com.horsecoder.auth.AuthConstant;
import com.horsecoder.auth.aop.deserializer.model.Body;
import com.horsecoder.auth.aop.resource.AuthResourceRetrieverAdapter;
import com.horsecoder.auth.aop.resource.ResourceRetrieveType;
import com.horsecoder.auth.authenticator.Authenticator;
import com.horsecoder.auth.authenticator.AuthenticatorHolder;
import com.horsecoder.common.chain.ChainContextHolder;
import com.googlecode.aviator.AviatorEvaluator;
import com.googlecode.aviator.Expression;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Author: Zhu yuhan
 * Email: zhuyuhan2333@qq.com
 * Date: 2021/11/19 7:07 下午
 **/
public class AuthExpressionRetriever extends AuthResourceRetrieverAdapter {

    private Authenticator authenticator;

    public AuthExpressionRetriever() {
        this.authenticator = AuthenticatorHolder.get();
    }

    @Override
    public boolean retrieve(String expressionString, HttpServletRequest request) {
        HttpServletResponse response = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getResponse();
        if (!this.authenticator.open(request, response)) return true;
        String uri = request.getRequestURI();
        Body body = (Body) ChainContextHolder.get(AuthConstant.REQUEST_BODY_KEY);
        try {
            Expression expression = AviatorEvaluator.compile(expressionString);
            List<String> variableNames = expression.getVariableNames();
            String a2 = null;
            if (variableNames.size() > 1) {
                a2 = variableNames.get(1);
            }
            String a1 = variableNames.get(0);

            Object requestValue = authenticator.getRequestValue(request, response, a1);
            Object contextValue = authenticator.getContextValue(request, response, a2);

            Map<String, Object> env = new HashMap<>();
            env.put(a1, requestValue);
            env.put(a2, contextValue);
            boolean innerExecute = (Boolean) expression.execute(env) && (requestValue != null || contextValue != null);
            return authenticator.checkExpression(request, response, uri, expressionString, innerExecute, body);
        } catch (Exception e) {
            return authenticator.checkExpression(request, response, uri, expressionString, false, body);
        }
    }

    @Override
    public ResourceRetrieveType type() {
        return ResourceRetrieveType.EXPRESSION;
    }
}
