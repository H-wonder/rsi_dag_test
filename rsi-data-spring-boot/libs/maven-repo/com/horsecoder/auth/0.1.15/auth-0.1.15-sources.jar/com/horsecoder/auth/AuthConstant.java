package com.horsecoder.auth;

/**
 * Author: Zhu yuhan
 * Email: zhuyuhan2333@qq.com
 * Date: 2021/11/16 11:53 上午
 **/
public class AuthConstant {

    public static final String REQUEST_BODY_KEY = "REQUEST_BODY";

    public static final String AUTH_FLOW_RESULT_KEY = "AUTH_FLOW_RESULT";

    public static final String AUTH_FLOW_ENGINE_KEY = "AUTH_FLOW_ENGINE";

    public static final String AUTH_FLOW_REQUEST_KEY = "AUTH_FLOW_REQUEST";

    public static final String AUTH_FLOW_MAP_KEY = "AUTH_FLOW_MAP";

    public static final String AUTH_FLOW_SCOPE = "auth";

}