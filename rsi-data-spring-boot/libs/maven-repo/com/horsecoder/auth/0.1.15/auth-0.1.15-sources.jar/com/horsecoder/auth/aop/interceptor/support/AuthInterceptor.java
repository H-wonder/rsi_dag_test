package com.horsecoder.auth.aop.interceptor.support;


import com.horsecoder.auth.Auth;
import com.horsecoder.auth.Logical;
import com.horsecoder.auth.aop.interceptor.BaseAnnotationMethodInterceptor;
import com.horsecoder.auth.aop.interceptor.MethodInterceptor;
import com.horsecoder.auth.aop.resolver.support.SpringAnnotationResolver;
import com.horsecoder.auth.authenticator.Authenticator;
import com.horsecoder.auth.authenticator.AuthenticatorHolder;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.annotation.Annotation;
import java.util.Arrays;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-08-10 19:42:52
 */
public class AuthInterceptor extends BaseAnnotationMethodInterceptor {

    private Queue<Logical> logicalQueue = new ConcurrentLinkedQueue<>();

    public AuthInterceptor(MethodInterceptor methodInterceptor) {
        super(new SpringAnnotationResolver(), Auth.class, methodInterceptor);
    }

    @Override
    public void assertAuthorized(MethodInvocation methodInvocation, Annotation annotation) throws Exception {
        if (!(annotation instanceof Auth)) return;
        Auth authAnnotation = (Auth) annotation;
        Authenticator authenticator = AuthenticatorHolder.get();
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
        HttpServletResponse response = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getResponse();
        if (!authenticator.open(request, response)) return;
        logicalQueue.add(Logical.AND);
        logicalQueue.addAll(Arrays.asList(authAnnotation.logical()));
    }

    @Override
    public Logical getLogical() {
        if (logicalQueue.isEmpty()) {
            return super.getLogical();
        }
        return logicalQueue.poll();
    }
}

