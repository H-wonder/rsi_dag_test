package com.horsecoder.auth.aop.resource.support;

import cc.eamon.open.flow.core.FlowEngine;
import cc.eamon.open.flow.core.context.FlowContextHolder;
import cc.eamon.open.flow.core.context.FlowScopeContext;
import com.horsecoder.auth.AuthConstant;
import com.horsecoder.auth.aop.resource.AuthResourceRetrieverAdapter;
import com.horsecoder.auth.aop.resource.ResourceRetrieveType;
import com.horsecoder.auth.util.AuthUtils;
import com.horsecoder.common.chain.ChainContextHolder;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

/**
 * Author: Zhu yuhan
 * Email: zhuyuhan2333@qq.com
 * Date: 2021/11/19 7:07 下午
 **/
public class AuthFlowRetriever extends AuthResourceRetrieverAdapter {

    @Override
    public boolean retrieve(String flowId, HttpServletRequest request) {
        if (StringUtils.isEmpty(flowId))
            return false;
        FlowEngine flowEngine = AuthUtils.getAuthFlowEngine();
        try {
            Map<String, Object> authContextMap = AuthUtils.getAuthContextMap();
            // combine flow map to deal with diy changes
            this.combineAuthContextMap(authContextMap);
            if (authContextMap == null || authContextMap.isEmpty()) {
                // get or delete and no reserve
                flowEngine.register(AuthConstant.AUTH_FLOW_SCOPE, AuthConstant.AUTH_FLOW_REQUEST_KEY, request);
            } else {
                authContextMap.forEach((key, value) -> flowEngine.register(AuthConstant.AUTH_FLOW_SCOPE, key, value));
            }
            flowEngine.run(flowId);
            Map<String, Object> result = flowEngine.retrieveFlowResults(flowId);
            return (Boolean) result.get(AuthConstant.AUTH_FLOW_RESULT_KEY);
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public ResourceRetrieveType type() {
        return ResourceRetrieveType.FLOW;
    }

    private void combineAuthContextMap(Map<String, Object> authContextMap) {
        Map<String, Object> flowAuthScopeMap = FlowContextHolder.get().getScopeParams(AuthConstant.AUTH_FLOW_SCOPE);
        if (!CollectionUtils.isEmpty(flowAuthScopeMap)) {
            authContextMap.putAll(flowAuthScopeMap);
            ChainContextHolder.put(AuthConstant.AUTH_FLOW_MAP_KEY, authContextMap);
        }
    }
}
