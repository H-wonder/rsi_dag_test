package com.horsecoder.auth.util;

import cc.eamon.open.flow.core.FlowEngine;
import com.horsecoder.auth.AuthConstant;
import com.horsecoder.auth.aop.deserializer.model.Body;
import com.horsecoder.common.chain.ChainContextHolder;

import java.util.HashMap;
import java.util.Map;

/**
 * Author: Zhu yuhan
 * Email: zhuyuhan2333@qq.com
 * Date: 2021/11/20 10:56 上午
 **/
public class AuthUtils {

    public static Map<String, Object> getAuthContextMap() {
        Map<String, Object> authContextMap = (Map<String, Object>) ChainContextHolder.get(AuthConstant.AUTH_FLOW_MAP_KEY);
        if (authContextMap == null) {
            initAuthContextMap();
            return (Map<String, Object>) ChainContextHolder.get(AuthConstant.AUTH_FLOW_MAP_KEY);
        }
        return authContextMap;
    }

    public static void releaseAuthFlowEngine() {
        FlowEngine flowEngine = (FlowEngine) ChainContextHolder.get(AuthConstant.AUTH_FLOW_ENGINE_KEY);
        if (flowEngine != null) {
            flowEngine.release();
            ChainContextHolder.remove(AuthConstant.AUTH_FLOW_ENGINE_KEY);
        }
    }

    public static FlowEngine getAuthFlowEngine() {
        FlowEngine flowEngine = (FlowEngine) ChainContextHolder.get(AuthConstant.AUTH_FLOW_ENGINE_KEY);
        if (flowEngine == null) {
            flowEngine = FlowEngine.instance();
            ChainContextHolder.put(AuthConstant.AUTH_FLOW_ENGINE_KEY, flowEngine);
        }
        return flowEngine;
    }

    private static void initAuthContextMap() {
        Body body = (Body) ChainContextHolder.get(AuthConstant.REQUEST_BODY_KEY);
        if (body == null) {
            // no post body, but reserve something else
            ChainContextHolder.put(AuthConstant.AUTH_FLOW_MAP_KEY, new HashMap<String, Object>());
        } else
            ChainContextHolder.put(AuthConstant.AUTH_FLOW_MAP_KEY, body.toMap());

    }

}
