package cc.eamon.open.auto.config.app.builder;

import cc.eamon.open.auto.config.AutoConfigBuilder;
import cc.eamon.open.auto.config.app.detail.ServiceAppConfig;
import cc.eamon.open.auto.config.app.detail.env.EnvConfig;

import java.util.ArrayList;
import java.util.List;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-09-06 15:24:29
 */
public class ServiceAppConfigBuilder implements AutoConfigBuilder {

    private String id;

    private String familyId;

    private boolean build;

    private boolean deploy;

    private boolean run;

    private String projectTitle;

    private String groupId;

    private String artifactId;

    private String version;

    private String location;

    private String name;

    private String description;

    private String port;

    private List<EnvConfig> centerIds = new ArrayList<>();

    private List<EnvConfig> databaseIds = new ArrayList<>();

    public ServiceAppConfigBuilder() {
    }

    public ServiceAppConfigBuilder(String id, String familyId, boolean build, boolean deploy, boolean run, String projectTitle, String groupId, String artifactId, String version, String location, String name, String description, String port, List<EnvConfig> centerIds, List<EnvConfig> databaseIds) {
        this.id = id;
        this.familyId = familyId;
        this.build = build;
        this.deploy = deploy;
        this.run = run;
        this.projectTitle = projectTitle;
        this.groupId = groupId;
        this.artifactId = artifactId;
        this.version = version;
        this.location = location;
        this.name = name;
        this.description = description;
        this.port = port;
        this.centerIds = centerIds;
        this.databaseIds = databaseIds;
    }


    @Override
    public ServiceAppConfig build() {
        validate();
        return new ServiceAppConfig(id, familyId, build, deploy, run, projectTitle, groupId, artifactId, version, location, name, description, port, centerIds, databaseIds);
    }

    @Override
    public void validate() {

    }

    public ServiceAppConfigBuilder setId(String id) {
        this.id = id;
        return this;
    }

    public ServiceAppConfigBuilder setBuild(boolean build) {
        this.build = build;
        return this;
    }

    public ServiceAppConfigBuilder setDeploy(boolean deploy) {
        this.deploy = deploy;
        return this;
    }

    public ServiceAppConfigBuilder setRun(boolean run) {
        this.run = run;
        return this;
    }

    public ServiceAppConfigBuilder addFamilyId(String familyId) {
        this.familyId = familyId;
        return this;
    }

    public ServiceAppConfigBuilder addProjectTitle(String projectTitle) {
        this.projectTitle = projectTitle;
        return this;
    }

    public ServiceAppConfigBuilder addGroupId(String groupId) {
        this.groupId = groupId;
        return this;
    }

    public ServiceAppConfigBuilder addArtifactId(String artifactId) {
        this.artifactId = artifactId;
        return this;
    }

    public ServiceAppConfigBuilder addVersion(String version) {
        this.version = version;
        return this;
    }

    public ServiceAppConfigBuilder addLocation(String location) {
        this.location = location;
        return this;
    }

    public ServiceAppConfigBuilder addName(String name) {
        this.name = name;
        return this;
    }

    public ServiceAppConfigBuilder addDescription(String description) {
        this.description = description;
        return this;
    }

    public ServiceAppConfigBuilder addPort(String port) {
        this.port = port;
        return this;
    }

    public ServiceAppConfigBuilder addCenter(String env, CenterAppConfigBuilder center) {
        centerIds.add(new EnvConfig(env, center.getId()));
        return this;
    }

    public ServiceAppConfigBuilder addDatabase(String env, DatabaseAppConfigBuilder database) {
        databaseIds.add(new EnvConfig(env, database.getId()));
        return this;
    }

}
