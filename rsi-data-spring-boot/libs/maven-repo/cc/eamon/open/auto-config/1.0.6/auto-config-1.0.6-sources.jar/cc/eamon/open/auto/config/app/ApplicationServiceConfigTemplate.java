package cc.eamon.open.auto.config.app;

import cc.eamon.open.auto.config.app.detail.*;

import java.util.List;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-02-20 18:14:39
 */
public class ApplicationServiceConfigTemplate implements AppConfig {

    private String id;

    private boolean build;

    private boolean deploy;

    private boolean run;

    private List<CenterAppConfig> centers;

    private List<GatewayAppConfig> gateways;

    private List<ServiceAppConfig> services;

    private List<DatabaseAppConfig> databases;

    public ApplicationServiceConfigTemplate() {
    }

    public ApplicationServiceConfigTemplate(String id, boolean build, boolean deploy, boolean run, List<CenterAppConfig> centers, List<GatewayAppConfig> gateways, List<ServiceAppConfig> services, List<DatabaseAppConfig> databases) {
        this.id = id;
        this.build = build;
        this.deploy = deploy;
        this.run = run;
        this.centers = centers;
        this.gateways = gateways;
        this.services = services;
        this.databases = databases;
    }

//    @Override
//    public boolean equals(Object o) {
//        if (this == o) return true;
//        if (o == null || getClass() != o.getClass()) return false;
//        ApplicationTemplateConfig that = (ApplicationTemplateConfig) o;
//        boolean equalStatus = center.equals(that.center) &&
//                gateway.equals(that.gateway);
//
//        for (ServiceAppConfig service : services) {
//            boolean status = false;
//            for (ServiceAppConfig serviceAppConfig : that.services) {
//                if (service.equals(serviceAppConfig)) {
//                    status = true;
//                    break;
//                }
//            }
//            equalStatus = equalStatus & status;
//        }
//
//        for (DatabaseAppConfig database : databases) {
//            boolean status = false;
//            for (DatabaseAppConfig databaseAppConfig : that.databases) {
//                if (database.equals(databaseAppConfig)) {
//                    status = true;
//                    break;
//                }
//            }
//            equalStatus = equalStatus & status;
//        }
//
//        return equalStatus;
//    }
//
//    @Override
//    public int hashCode() {
//        return Objects.hash(center, gateway, services, databases);
//    }


    @Override
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public boolean isBuild() {
        return build;
    }

    public void setBuild(boolean build) {
        this.build = build;
    }

    @Override
    public boolean isDeploy() {
        return deploy;
    }

    public void setDeploy(boolean deploy) {
        this.deploy = deploy;
    }

    @Override
    public boolean isRun() {
        return run;
    }

    public void setRun(boolean run) {
        this.run = run;
    }

    public List<CenterAppConfig> getCenters() {
        return centers;
    }

    public void setCenters(List<CenterAppConfig> centers) {
        this.centers = centers;
    }

    public List<GatewayAppConfig> getGateways() {
        return gateways;
    }

    public void setGateways(List<GatewayAppConfig> gateways) {
        this.gateways = gateways;
    }

    public List<ServiceAppConfig> getServices() {
        return services;
    }

    public void setServices(List<ServiceAppConfig> services) {
        this.services = services;
    }

    public List<DatabaseAppConfig> getDatabases() {
        return databases;
    }

    public void setDatabases(List<DatabaseAppConfig> databases) {
        this.databases = databases;
    }
}
