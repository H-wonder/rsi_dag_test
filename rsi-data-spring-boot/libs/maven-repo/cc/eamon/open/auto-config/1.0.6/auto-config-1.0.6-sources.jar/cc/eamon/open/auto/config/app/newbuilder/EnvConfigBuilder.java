package cc.eamon.open.auto.config.app.newbuilder;

import cc.eamon.open.auto.config.AutoConfigBuilder;
import cc.eamon.open.auto.config.app.detail.env.EnvConfig;
import org.springframework.util.Assert;

/**
 * @author lzr
 * @date 2021/1/28 23:01
 */
public class EnvConfigBuilder implements AutoConfigBuilder {

    private final EnvConfig envConfig;

    public EnvConfigBuilder(EnvConfig envConfig){
        this.envConfig = envConfig;
    }

    @Override
    public EnvConfig build() {
        validate();
        return envConfig;
    }

    @Override
    public void validate() {
        Assert.notNull(envConfig, "env config null");
        Assert.notNull(envConfig.getEnv(), "env env null");
        Assert.notNull(envConfig.getValue(), "env value null");
    }

    public String getEnv(){
        return envConfig.getEnv();
    }

    public void setEnv(String env){
        envConfig.setEnv(env);
    }

    public String getValue(){
        return envConfig.getValue();
    }

    public void setValue(String value){
        envConfig.setValue(value);
    }
}
