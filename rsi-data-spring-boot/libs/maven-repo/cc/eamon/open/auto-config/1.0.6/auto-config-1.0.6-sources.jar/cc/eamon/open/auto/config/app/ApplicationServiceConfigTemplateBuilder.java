package cc.eamon.open.auto.config.app;

import cc.eamon.open.auto.config.AutoConfigBuilder;
import cc.eamon.open.auto.config.app.builder.CenterAppConfigBuilder;
import cc.eamon.open.auto.config.app.builder.DatabaseAppConfigBuilder;
import cc.eamon.open.auto.config.app.builder.GatewayAppConfigBuilder;
import cc.eamon.open.auto.config.app.builder.ServiceAppConfigBuilder;
import cc.eamon.open.auto.config.app.detail.CenterAppConfig;
import cc.eamon.open.auto.config.app.detail.DatabaseAppConfig;
import cc.eamon.open.auto.config.app.detail.GatewayAppConfig;
import cc.eamon.open.auto.config.app.detail.ServiceAppConfig;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.List;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-09-06 15:18:32
 */
public class ApplicationServiceConfigTemplateBuilder implements AutoConfigBuilder {

    private String id;

    private boolean build = true;

    private boolean deploy = true;

    private boolean run = true;

    private List<CenterAppConfig> centers = new ArrayList<>();

    private List<GatewayAppConfig> gateways = new ArrayList<>();

    private List<ServiceAppConfig> services = new ArrayList<>();

    private List<DatabaseAppConfig> databases = new ArrayList<>();

    public ApplicationServiceConfigTemplateBuilder() {
    }

    @Override
    public ApplicationServiceConfigTemplate build() {
        validate();
        return new ApplicationServiceConfigTemplate(id, build, deploy, run, centers, gateways, services, databases);
    }

    @Override
    public void validate() {
        // TODO: NEED COVER TEST
        Assert.notEmpty(centers, "centers can't be null");
        Assert.notEmpty(gateways, "gateways can't be null");
        Assert.notEmpty(databases, "databases can't be null");
        Assert.notEmpty(services, "services can't be null");
    }

    public ApplicationServiceConfigTemplateBuilder setId(String id) {
        this.id = id;
        return this;
    }

    public ApplicationServiceConfigTemplateBuilder setBuild(boolean build) {
        this.build = build;
        return this;
    }

    public ApplicationServiceConfigTemplateBuilder setDeploy(boolean deploy) {
        this.deploy = deploy;
        return this;
    }

    public ApplicationServiceConfigTemplateBuilder setRun(boolean run) {
        this.run = run;
        return this;
    }

    public ApplicationServiceConfigTemplateBuilder addCenters(CenterAppConfigBuilder... centers) {
        for (CenterAppConfigBuilder center : centers) {
            this.centers.add(center.build());
        }
        return this;
    }

    public ApplicationServiceConfigTemplateBuilder addGateways(GatewayAppConfigBuilder... gateways) {
        for (GatewayAppConfigBuilder gateway : gateways) {
            this.gateways.add(gateway.build());
        }
        return this;
    }

    public ApplicationServiceConfigTemplateBuilder addServices(ServiceAppConfigBuilder... services) {
        for (ServiceAppConfigBuilder service : services) {
            this.services.add(service.build());
        }
        return this;
    }

    public ApplicationServiceConfigTemplateBuilder addDatabases(DatabaseAppConfigBuilder... databases) {
        for (DatabaseAppConfigBuilder database : databases) {
            this.databases.add(database.build());
        }
        return this;
    }
}
