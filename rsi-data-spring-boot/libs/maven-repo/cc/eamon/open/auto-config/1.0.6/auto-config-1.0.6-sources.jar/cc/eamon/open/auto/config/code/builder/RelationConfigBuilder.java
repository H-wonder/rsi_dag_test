package cc.eamon.open.auto.config.code.builder;

import cc.eamon.open.auto.config.AutoConfigBuilder;
import cc.eamon.open.auto.config.code.detail.RelationConfig;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

import java.util.List;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-09-08 16:01:22
 */
public class RelationConfigBuilder implements AutoConfigBuilder {

    private RelationConfig relationConfig;

    public RelationConfigBuilder() {
    }

    public RelationConfigBuilder(RelationConfig relationConfig) {
        this.relationConfig = relationConfig;
    }

    @Override
    public RelationConfig build() {
        validate();
        return relationConfig;
    }

    @Override
    public void validate() {
        Assert.notNull(relationConfig, "relation config null");
        Assert.notNull(relationConfig.getId(), "relation id null");
        Assert.notNull(relationConfig.getRelationType(), "relation type null");
        Assert.notNull(relationConfig.getRelationName(), "relation name null");
        Assert.notNull(relationConfig.getRelationTitle(), "relation title null");
        Assert.notNull(relationConfig.getModelMainId(), "relation model main id null");
        Assert.isTrue(!CollectionUtils.isEmpty(relationConfig.getModelMainKey()), "relation model main key null");
        Assert.notNull(relationConfig.getModelRelatedId(), "relation model main id null");
        Assert.isTrue(!CollectionUtils.isEmpty(relationConfig.getModelRelatedKey()), "relation model related key null");
    }

    public String getId() {
        return relationConfig.getId();
    }

    public void setId(String id) {
        relationConfig.setId(id);
    }

    public String getModelMainId() {
        return relationConfig.getModelMainId();
    }

    public void setModelMainId(String modelMainId) {
        relationConfig.setModelMainId(modelMainId);
    }

    public List<String> getModelMainKey() {
        return relationConfig.getModelMainKey();
    }

    public void setModelMainKey(List<String> modelMainKey) {
        relationConfig.setModelMainKey(modelMainKey);
    }

    public String getModelRelatedId() {
        return relationConfig.getModelRelatedId();
    }

    public void setModelRelatedId(String modelRelatedId) {
        relationConfig.setModelRelatedId(modelRelatedId);
    }

    public List<String> getModelRelatedKey() {
        return relationConfig.getModelRelatedKey();
    }

    public void setModelRelatedKey(List<String> modelRelatedKey) {
        relationConfig.setModelRelatedKey(modelRelatedKey);
    }

    public String getRelationType() {
        return relationConfig.getRelationType();
    }

    public void setRelationType(String relationType) {
        relationConfig.setRelationType(relationType);
    }

    public String getRelationName() {
        return relationConfig.getRelationName();
    }

    public void setRelationName(String relationName) {
        relationConfig.setRelationName(relationName);
    }

    public String getRelationTitle() {
        return relationConfig.getRelationTitle();
    }

    public void setRelationTitle(String relationTitle) {
        relationConfig.setRelationTitle(relationTitle);
    }

    public Boolean getAtLeastOne() {
        return relationConfig.getAtLeastOne();
    }

    public void setAtLeastOne(Boolean atLeastOne) {
        relationConfig.setAtLeastOne(atLeastOne);
    }


}
