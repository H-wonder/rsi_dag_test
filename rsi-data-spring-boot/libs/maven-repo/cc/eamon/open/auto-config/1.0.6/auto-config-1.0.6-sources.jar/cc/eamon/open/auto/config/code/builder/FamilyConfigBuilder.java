package cc.eamon.open.auto.config.code.builder;

import cc.eamon.open.auto.config.AutoConfigBuilder;
import cc.eamon.open.auto.config.code.detail.FamilyConfig;
import org.springframework.util.Assert;

import java.util.List;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-09-08 16:01:43
 */
public class FamilyConfigBuilder implements AutoConfigBuilder {

    private FamilyConfig familyConfig;

    public FamilyConfigBuilder() {
    }

    public FamilyConfigBuilder(FamilyConfig familyConfig) {
        this.familyConfig = familyConfig;
    }

    @Override
    public FamilyConfig build() {
        validate();
        return familyConfig;
    }

    @Override
    public void validate() {
        Assert.notNull(familyConfig, "family config null");
        Assert.notNull(familyConfig.getId(), "family id null");
        Assert.notNull(familyConfig.getName(), "family name null");
        Assert.notNull(familyConfig.getGroupId(), "family group id null");
        Assert.notNull(familyConfig.getArtifactId(), "family artifact id null");
        Assert.notNull(familyConfig.getVersion(), "family version null");
        Assert.notNull(familyConfig.getFamilyTitle(), "family title null");
    }


    public String getId() {
        return familyConfig.getId();
    }

    public void setId(String id) {
        familyConfig.setId(id);
    }

    public String getName() {
        return familyConfig.getName();
    }

    public void setName(String name) {
        familyConfig.setName(name);
    }

    public String getGroupId() {
        return familyConfig.getGroupId();
    }

    public void setGroupId(String groupId) {
        familyConfig.setGroupId(groupId);
    }

    public String getArtifactId() {
        return familyConfig.getArtifactId();
    }

    public void setArtifactId(String artifactId) {
        familyConfig.setArtifactId(artifactId);
    }

    public String getVersion() {
        return familyConfig.getVersion();
    }

    public void setVersion(String version) {
        familyConfig.setVersion(version);
    }

    public String getFamilyTitle() {
        return familyConfig.getFamilyTitle();
    }

    public void setFamilyTitle(String familyTitle) {
        familyConfig.setFamilyTitle(familyTitle);
    }

    public List<String> getModelIds() {
        return familyConfig.getModelIds();
    }

    public void setModelIds(List<String> modelIds) {
        familyConfig.setModelIds(modelIds);
    }

    public List<String> getFlowIds() {
        return familyConfig.getFlowIds();
    }

    public void setFlowIds(List<String> flowIds) {
        familyConfig.setFlowIds(flowIds);
    }

}
