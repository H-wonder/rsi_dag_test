package cc.eamon.open.auto.config.app.detail;

import cc.eamon.open.auto.config.app.detail.env.EnvConfig;

import java.util.ArrayList;
import java.util.List;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-02-20 17:53:36
 */
public class ServiceAppConfig implements SpringBootAppConfig {

    private String id;

    private String familyId;

    private boolean build;

    private boolean deploy;

    private boolean run;

    private String projectTitle;

    private String groupId;

    private String artifactId;

    private String version;

    private String location;

    private String name;

    private String description;

    private String port;

    private List<EnvConfig> centerIds = new ArrayList<>();

    private List<EnvConfig> databaseIds = new ArrayList<>();

    public ServiceAppConfig() {
    }

    public ServiceAppConfig(String id, String familyId, boolean build, boolean deploy, boolean run, String projectTitle, String groupId, String artifactId, String version, String location, String name, String description, String port, List<EnvConfig> centerIds, List<EnvConfig> databaseIds) {
        this.id = id;
        this.familyId = familyId;
        this.build = build;
        this.deploy = deploy;
        this.run = run;
        this.projectTitle = projectTitle;
        this.groupId = groupId;
        this.artifactId = artifactId;
        this.version = version;
        this.location = location;
        this.name = name;
        this.description = description;
        this.port = port;
        this.centerIds = centerIds;
        this.databaseIds = databaseIds;
    }

    @Override
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFamilyId() {
        return familyId;
    }

    public void setFamilyId(String familyId) {
        this.familyId = familyId;
    }

    @Override
    public boolean isBuild() {
        return build;
    }

    public void setBuild(boolean build) {
        this.build = build;
    }

    @Override
    public boolean isDeploy() {
        return deploy;
    }

    public void setDeploy(boolean deploy) {
        this.deploy = deploy;
    }

    @Override
    public boolean isRun() {
        return run;
    }

    public void setRun(boolean run) {
        this.run = run;
    }

    public String getProjectTitle() {
        return projectTitle;
    }

    public void setProjectTitle(String projectTitle) {
        this.projectTitle = projectTitle;
    }

    @Override
    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    @Override
    public String getArtifactId() {
        return artifactId;
    }

    public void setArtifactId(String artifactId) {
        this.artifactId = artifactId;
    }

    @Override
    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    @Override
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public List<EnvConfig> getCenterIds() {
        return centerIds;
    }

    public void setCenterIds(List<EnvConfig> centerIds) {
        this.centerIds = centerIds;
    }

    public List<EnvConfig> getDatabaseIds() {
        return databaseIds;
    }

    public void setDatabaseIds(List<EnvConfig> databaseIds) {
        this.databaseIds = databaseIds;
    }
}
