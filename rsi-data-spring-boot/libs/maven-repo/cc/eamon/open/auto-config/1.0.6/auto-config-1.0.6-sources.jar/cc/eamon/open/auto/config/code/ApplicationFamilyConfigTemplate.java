package cc.eamon.open.auto.config.code;

import cc.eamon.open.auto.config.code.detail.DataFamilyConfig;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2023-08-03 02:21:48
 */
public class ApplicationFamilyConfigTemplate extends DataFamilyConfig {
}
