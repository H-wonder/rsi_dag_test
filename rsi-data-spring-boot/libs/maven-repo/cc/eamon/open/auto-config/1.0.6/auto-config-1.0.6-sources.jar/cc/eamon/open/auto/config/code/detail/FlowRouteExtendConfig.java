package cc.eamon.open.auto.config.code.detail;

import cc.eamon.open.flow.config.flow.FlowRouteConfig;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2023-09-14 17:35:59
 */
public class FlowRouteExtendConfig extends FlowRouteConfig {

    public FlowRouteExtendConfig(FlowRouteConfig config) {
        setSource(config.getSource());
        setTarget(config.getTarget());
        setCondition(config.getCondition());
        setScope(config.getScope());
    }

}
