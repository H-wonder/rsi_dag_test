package cc.eamon.open.auto.config.app.detail;

import cc.eamon.open.auto.config.app.detail.env.EnvConfig;

import java.util.ArrayList;
import java.util.List;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-02-20 17:53:36
 */
public class GatewayAppConfig implements SpringBootAppConfig {

    private String id;

    private boolean build;

    private boolean deploy;

    private boolean run;

    private String location;

    private String groupId;

    private String artifactId;

    private String version;

    private String port;

    private String name;

    private String description;

    private List<EnvConfig> centerIds = new ArrayList<>();

    public GatewayAppConfig() {
    }

    public GatewayAppConfig(String id, boolean build, boolean deploy, boolean run, String location, String groupId, String artifactId, String version, String port, String name, String description, List<EnvConfig> centerIds) {
        this.id = id;
        this.build = build;
        this.deploy = deploy;
        this.run = run;
        this.location = location;
        this.groupId = groupId;
        this.artifactId = artifactId;
        this.version = version;
        this.port = port;
        this.name = name;
        this.description = description;
        this.centerIds = centerIds;
    }


    @Override
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public boolean isBuild() {
        return build;
    }

    public void setBuild(boolean build) {
        this.build = build;
    }

    @Override
    public boolean isDeploy() {
        return deploy;
    }

    public void setDeploy(boolean deploy) {
        this.deploy = deploy;
    }

    @Override
    public boolean isRun() {
        return run;
    }

    public void setRun(boolean run) {
        this.run = run;
    }

    @Override
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    @Override
    public String getArtifactId() {
        return artifactId;
    }

    public void setArtifactId(String artifactId) {
        this.artifactId = artifactId;
    }

    @Override
    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    @Override
    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    @Override
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<EnvConfig> getCenterIds() {
        return centerIds;
    }

    public void setCenterIds(List<EnvConfig> centerIds) {
        this.centerIds = centerIds;
    }
}
