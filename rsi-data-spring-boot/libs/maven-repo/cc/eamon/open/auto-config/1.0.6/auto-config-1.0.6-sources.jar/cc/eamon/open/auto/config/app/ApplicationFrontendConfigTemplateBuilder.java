package cc.eamon.open.auto.config.app;

import cc.eamon.open.auto.config.AutoConfigBuilder;
import cc.eamon.open.auto.config.app.builder.FrontendAppConfigBuilder;
import cc.eamon.open.auto.config.app.detail.FrontendAppConfig;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-09-18 11:14:16
 */
public class ApplicationFrontendConfigTemplateBuilder implements AutoConfigBuilder {

    private FrontendAppConfig project;

    @Override
    public ApplicationFrontendConfigTemplate build() {
        validate();
        return new ApplicationFrontendConfigTemplate(project);
    }

    @Override
    public void validate() {

    }

    public ApplicationFrontendConfigTemplateBuilder addProject(FrontendAppConfigBuilder project) {
        this.project = project.build();
        return this;
    }

}
