package cc.eamon.open.auto.config.app.detail.env;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-08-27 22:48:08
 */
public class EnvConfig {

    private String env;

    private String value;

    public EnvConfig() {
    }

    public EnvConfig(String env, String value) {
        this.env = env;
        this.value = value;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
