package cc.eamon.open.auto.config.app.detail;

import java.util.Objects;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-02-20 17:53:36
 */
public class CenterAppConfig implements SpringBootAppConfig {

    private String id;

    private boolean build;

    private boolean deploy;

    private boolean run;

    private String location;

    private String groupId;

    private String artifactId;

    private String version;

    private String host;

    private String port;

    private String name;

    private String description;

    public CenterAppConfig() {
    }

    public CenterAppConfig(String id, boolean build, boolean deploy, boolean run, String location, String groupId, String artifactId, String version, String host, String port, String name, String description) {
        this.id = id;
        this.build = build;
        this.deploy = deploy;
        this.run = run;
        this.location = location;
        this.groupId = groupId;
        this.artifactId = artifactId;
        this.version = version;
        this.host = host;
        this.port = port;
        this.name = name;
        this.description = description;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CenterAppConfig that = (CenterAppConfig) o;
        return build == that.build &&
                deploy == that.deploy &&
                run == that.run &&
                Objects.equals(id, that.id) &&
                Objects.equals(location, that.location) &&
                Objects.equals(groupId, that.groupId) &&
                Objects.equals(artifactId, that.artifactId) &&
                Objects.equals(version, that.version) &&
                Objects.equals(host, that.host) &&
                Objects.equals(port, that.port) &&
                Objects.equals(name, that.name) &&
                Objects.equals(description, that.description);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, build, deploy, run, location, groupId, artifactId, version, host, port, name, description);
    }

    @Override
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public boolean isBuild() {
        return build;
    }

    public void setBuild(boolean build) {
        this.build = build;
    }

    @Override
    public boolean isDeploy() {
        return deploy;
    }

    public void setDeploy(boolean deploy) {
        this.deploy = deploy;
    }

    @Override
    public boolean isRun() {
        return run;
    }

    public void setRun(boolean run) {
        this.run = run;
    }

    @Override
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    @Override
    public String getArtifactId() {
        return artifactId;
    }

    public void setArtifactId(String artifactId) {
        this.artifactId = artifactId;
    }

    @Override
    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    @Override
    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    @Override
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
