package cc.eamon.open.auto.config.code.builder;

import cc.eamon.open.auto.config.AutoConfigBuilder;
import cc.eamon.open.auto.config.code.detail.FieldConfig;
import cc.eamon.open.auto.config.code.detail.ModelConfig;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-09-08 16:01:22
 */
public class ModelConfigBuilder implements AutoConfigBuilder {

    private ModelConfig modelConfig;

    private List<FieldConfigBuilder> fields = new ArrayList<>();

    public ModelConfigBuilder() {
    }

    public ModelConfigBuilder(ModelConfig modelConfig) {
        this.modelConfig = modelConfig;
        for (FieldConfig field : modelConfig.getFields()) {
            this.fields.add(new FieldConfigBuilder(field));
        }
    }

    @Override
    public ModelConfig build() {
        List<FieldConfig> fields = new ArrayList<>();
        for (FieldConfigBuilder field : this.fields) {
            fields.add(field.build());
        }
        modelConfig.setFields(fields);
        validate();
        return modelConfig;
    }

    @Override
    public void validate() {
        if (StringUtils.isEmpty(modelConfig.getOrder())) {
            modelConfig.setOrder("gmtCreate desc");
        }
        Assert.notNull(modelConfig, "model config null");
        Assert.notNull(modelConfig.getId(), "model id null");
        Assert.notNull(modelConfig.getModule(), "model module null");
        Assert.notNull(modelConfig.getName(), "model name null");
        Assert.notNull(modelConfig.getModelTitle(), "model title null");
        Assert.isTrue(!CollectionUtils.isEmpty(modelConfig.getPk()), "model pk empty");
        Assert.isTrue(!CollectionUtils.isEmpty(modelConfig.getFields()), "model fields empty");
        Assert.notNull(modelConfig.getOrder(), "model order null");
    }

    public String getId() {
        return modelConfig.getId();
    }

    public void setId(String id) {
        modelConfig.setId(id);
    }

    public String getModule() {
        return modelConfig.getModule();
    }

    public void setModule(String module) {
        modelConfig.setModule(module);
    }

    public String getName() {
        return modelConfig.getName();
    }

    public void setName(String name) {
        modelConfig.setName(name);
    }

    public String getModelTitle() {
        return modelConfig.getModelTitle();
    }

    public void setModelTitle(String modelTitle) {
        modelConfig.setModelTitle(modelTitle);
    }

    public List<FieldConfig> getFields() {
        return modelConfig.getFields();
    }

    public void setFields(List<FieldConfig> fields) {
        modelConfig.setFields(fields);
    }

    public List<String> getPk() {
        return modelConfig.getPk();
    }

    public void setPk(List<String> pk) {
        modelConfig.setPk(pk);
    }

    public String getOrder() {
        return modelConfig.getOrder();
    }

    public void setOrder(String order) {
        modelConfig.setOrder(order);
    }

}
