package cc.eamon.open.auto.config.app.newbuilder;

import cc.eamon.open.auto.config.AutoConfigBuilder;
import cc.eamon.open.auto.config.app.detail.CenterAppConfig;
import org.springframework.util.Assert;

/**
 * @author lzr
 * @date 2021/1/28 21:42
 */
public class CenterAppConfigBuilder implements AutoConfigBuilder {

    private final CenterAppConfig centerAppConfig;

    public CenterAppConfigBuilder(CenterAppConfig centerAppConfig){
        this.centerAppConfig = centerAppConfig;
    }


    @Override
    public CenterAppConfig build() {
        validate();
        return centerAppConfig;
    }

    @Override
    public void validate() {
        Assert.notNull(centerAppConfig, "centerApp config null");
        Assert.notNull(centerAppConfig.getId(), "centerApp id null");
        Assert.notNull(centerAppConfig.getLocation(), "centerApp location null");
        Assert.notNull(centerAppConfig.getGroupId(), "centerApp groupId null");
        Assert.notNull(centerAppConfig.getArtifactId(), "centerApp artifactId null");
        Assert.notNull(centerAppConfig.getVersion(), "centerApp version null");
        Assert.notNull(centerAppConfig.getHost(), "centerApp host null");
        Assert.notNull(centerAppConfig.getPort(), "centerApp port null");
        Assert.notNull(centerAppConfig.getName(), "centerApp name null");
        Assert.notNull(centerAppConfig.getDescription(), "centerApp description null");
    }

    public String getName(){
        return centerAppConfig.getName();
    }

    public void setName(String name){
        centerAppConfig.setName(name);
    }

    public String getDescription(){
        return centerAppConfig.getDescription();
    }

    public void setDescription(String description){
        centerAppConfig.setDescription(description);
    }

    public String getVersion(){
        return centerAppConfig.getVersion();
    }

    public void setVersion(String version){
        centerAppConfig.setVersion(version);
    }

    public String getHost(){
        return centerAppConfig.getHost();
    }

    public void setHost(String host){
        centerAppConfig.setHost(host);
    }

    public String getPort(){
        return centerAppConfig.getPort();
    }

    public void setPort(String port){
        centerAppConfig.setPort(port);
    }

    public String getGroupId(){
        return centerAppConfig.getGroupId();
    }

    public void setGroupId(String groupId){
        centerAppConfig.setGroupId(groupId);
    }

    public String getArtifactId(){
        return centerAppConfig.getArtifactId();
    }

    public void setArtifactId(String artifactId){
        centerAppConfig.setArtifactId(artifactId);
    }

    public String getId(){
        return centerAppConfig.getId();
    }

    public void setId(String id){
        centerAppConfig.setId(id);
    }

    public String getLocation(){
        return centerAppConfig.getLocation();
    }

    public void setLocation(String location){
        centerAppConfig.setLocation(location);
    }

    public boolean isBuild(){
        return centerAppConfig.isBuild();
    }

    public void setBuild(boolean build){
        centerAppConfig.setBuild(build);
    }

    public boolean isDeploy(){
        return centerAppConfig.isDeploy();
    }

    public void setDeploy(boolean deploy){
        centerAppConfig.setDeploy(deploy);
    }

    public boolean isRun(){
        return centerAppConfig.isRun();
    }

    public void setRun(boolean run){
        centerAppConfig.setRun(run);
    }

}
