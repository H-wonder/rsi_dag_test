package cc.eamon.open.auto.config.app.detail;

import cc.eamon.open.auto.config.app.AppConfig;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-02-20 19:57:10
 */
public class FrontendAppConfig implements AppConfig {

    private String id;

    private boolean build;

    private boolean deploy;

    private boolean run;

    private String projectTitle;

    private String projectDescription;

    private String version;

    private String name;

    private String description;

    private String location;

    private String remote;

    private String baseUrl;

    public FrontendAppConfig() {
    }

    public FrontendAppConfig(
            String id,
            boolean build,
            boolean deploy,
            boolean run,
            String projectTitle,
            String projectDescription,
            String version,
            String name,
            String description,
            String location,
            String remote,
            String baseUrl
    ) {
        this.id = id;
        this.build = build;
        this.deploy = deploy;
        this.run = run;
        this.projectTitle = projectTitle;
        this.projectDescription = projectDescription;
        this.version = version;
        this.name = name;
        this.description = description;
        this.location = location;
        this.remote = remote;
        this.baseUrl = baseUrl;
    }

    @Override
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public boolean isBuild() {
        return build;
    }

    public void setBuild(boolean build) {
        this.build = build;
    }

    @Override
    public boolean isDeploy() {
        return deploy;
    }

    public void setDeploy(boolean deploy) {
        this.deploy = deploy;
    }

    @Override
    public boolean isRun() {
        return run;
    }

    public void setRun(boolean run) {
        this.run = run;
    }

    public String getProjectTitle() {
        return projectTitle;
    }

    public void setProjectTitle(String projectTitle) {
        this.projectTitle = projectTitle;
    }

    public String getProjectDescription() {
        return projectDescription;
    }

    public void setProjectDescription(String projectDescription) {
        this.projectDescription = projectDescription;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getRemote() {
        return remote;
    }

    public void setRemote(String remote) {
        this.remote = remote;
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

}
