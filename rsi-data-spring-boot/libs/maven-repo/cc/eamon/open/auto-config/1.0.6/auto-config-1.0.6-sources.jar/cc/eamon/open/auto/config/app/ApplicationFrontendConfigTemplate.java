package cc.eamon.open.auto.config.app;

import cc.eamon.open.auto.config.app.detail.FrontendAppConfig;

import java.util.Objects;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-02-22 17:40:10
 */
public class ApplicationFrontendConfigTemplate {

    private FrontendAppConfig project;

    public ApplicationFrontendConfigTemplate() {
    }

    public ApplicationFrontendConfigTemplate(FrontendAppConfig project) {
        this.project = project;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ApplicationFrontendConfigTemplate that = (ApplicationFrontendConfigTemplate) o;
        return Objects.equals(project, that.project);
    }

    @Override
    public int hashCode() {
        return Objects.hash(project);
    }

    public FrontendAppConfig getProject() {
        return project;
    }

    public void setProject(FrontendAppConfig project) {
        this.project = project;
    }
}
