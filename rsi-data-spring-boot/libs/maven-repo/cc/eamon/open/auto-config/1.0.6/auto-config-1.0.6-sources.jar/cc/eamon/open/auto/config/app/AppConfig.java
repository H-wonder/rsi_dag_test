package cc.eamon.open.auto.config.app;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-02-20 18:52:25
 */
public interface AppConfig {

    String getId();

    boolean isBuild();

    boolean isDeploy();

    boolean isRun();

}
