package cc.eamon.open.auto.config.app.newbuilder;

import cc.eamon.open.auto.config.AutoConfigBuilder;
import cc.eamon.open.auto.config.app.detail.ServiceAppConfig;
import cc.eamon.open.auto.config.app.detail.env.EnvConfig;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.List;

/**
 * @author lzr
 * @date 2021/1/28 23:12
 */
public class ServiceAppConfigBuilder implements AutoConfigBuilder {

    private final ServiceAppConfig serviceAppConfig;

    private final List<EnvConfigBuilder> centerIds = new ArrayList<>();

    private final List<EnvConfigBuilder> databaseIds = new ArrayList<>();

    public ServiceAppConfigBuilder(ServiceAppConfig serviceAppConfig){
        this.serviceAppConfig = serviceAppConfig;
        for(EnvConfig config : serviceAppConfig.getCenterIds()){
            this.centerIds.add(new EnvConfigBuilder(config));
        }

        for(EnvConfig config : serviceAppConfig.getDatabaseIds()){
            this.databaseIds.add(new EnvConfigBuilder(config));
        }
    }


    @Override
    public ServiceAppConfig build() {
        List<EnvConfig> centerIds = new ArrayList<>();
        List<EnvConfig> databaseIds = new ArrayList<>();
        for(EnvConfigBuilder builder : this.centerIds){
            centerIds.add(builder.build());
        }
        this.serviceAppConfig.setCenterIds(centerIds);

        for(EnvConfigBuilder builder : this.databaseIds){
            databaseIds.add(builder.build());
        }
        this.serviceAppConfig.setDatabaseIds(databaseIds);

        validate();
        return serviceAppConfig;
    }


    @Override
    public void validate() {
        Assert.notNull(serviceAppConfig, "serviceApp config null");
        Assert.notNull(serviceAppConfig.getFamilyId(), "serviceApp familyId null");
        Assert.notNull(serviceAppConfig.getProjectTitle(), "serviceApp projectTitle null");
        Assert.notNull(serviceAppConfig.getId(), "serviceApp id null");
        Assert.notNull(serviceAppConfig.getLocation(), "serviceApp location null");
        Assert.notNull(serviceAppConfig.getGroupId(), "serviceApp groupId null");
        Assert.notNull(serviceAppConfig.getArtifactId(), "serviceApp artifactId null");
        Assert.notNull(serviceAppConfig.getVersion(), "serviceApp version null");
        Assert.notNull(serviceAppConfig.getPort(), "serviceApp port null");
        Assert.notNull(serviceAppConfig.getName(), "serviceApp name null");
        Assert.notNull(serviceAppConfig.getDescription(), "serviceApp description null");
        Assert.notNull(serviceAppConfig.getCenterIds(), "serviceApp centerIds null");
        Assert.notNull(serviceAppConfig.getDatabaseIds(), "serviceApp databaseIds null");
    }

    public List<EnvConfig> getCenterIds(){
        return serviceAppConfig.getCenterIds();
    }

    public void setCenterIds(List<EnvConfig> centerIds){
        serviceAppConfig.setCenterIds(centerIds);
    }

    public List<EnvConfig> getDatabaseIds(){
        return serviceAppConfig.getDatabaseIds();
    }

    public void setDatabaseIds(List<EnvConfig> databaseIds){
        serviceAppConfig.setDatabaseIds(databaseIds);
    }

    public String getProjectTitle(){
        return serviceAppConfig.getProjectTitle();
    }

    public void setProjectTitle(String projectTitle){
        serviceAppConfig.setProjectTitle(projectTitle);
    }

    public String getFamilyId(){
        return serviceAppConfig.getFamilyId();
    }

    public void setFamilyId(String familyId){
        serviceAppConfig.setFamilyId(familyId);
    }

    public String getName(){
        return serviceAppConfig.getName();
    }

    public void setName(String name){
        serviceAppConfig.setName(name);
    }

    public String getDescription(){
        return serviceAppConfig.getDescription();
    }

    public void setDescription(String description){
        serviceAppConfig.setDescription(description);
    }

    public String getVersion(){
        return serviceAppConfig.getVersion();
    }

    public void setVersion(String version){
        serviceAppConfig.setVersion(version);
    }

    public String getPort(){
        return serviceAppConfig.getPort();
    }

    public void setPort(String port){
        serviceAppConfig.setPort(port);
    }

    public String getGroupId(){
        return serviceAppConfig.getGroupId();
    }

    public void setGroupId(String groupId){
        serviceAppConfig.setGroupId(groupId);
    }

    public String getArtifactId(){
        return serviceAppConfig.getArtifactId();
    }

    public void setArtifactId(String artifactId){
        serviceAppConfig.setArtifactId(artifactId);
    }

    public String getId(){
        return serviceAppConfig.getId();
    }

    public void setId(String id){
        serviceAppConfig.setId(id);
    }

    public String getLocation(){
        return serviceAppConfig.getLocation();
    }

    public void setLocation(String location){
        serviceAppConfig.setLocation(location);
    }

    public boolean isBuild(){
        return serviceAppConfig.isBuild();
    }

    public void setBuild(boolean build){
        serviceAppConfig.setBuild(build);
    }

    public boolean isDeploy(){
        return serviceAppConfig.isDeploy();
    }

    public void setDeploy(boolean deploy){
        serviceAppConfig.setDeploy(deploy);
    }

    public boolean isRun(){
        return serviceAppConfig.isRun();
    }

    public void setRun(boolean run){
        serviceAppConfig.setRun(run);
    }
}
