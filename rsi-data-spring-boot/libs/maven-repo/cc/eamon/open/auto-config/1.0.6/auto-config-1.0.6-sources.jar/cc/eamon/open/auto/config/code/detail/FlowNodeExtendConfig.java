package cc.eamon.open.auto.config.code.detail;

import cc.eamon.open.flow.config.flow.FlowNodeConfig;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2023-09-14 17:35:59
 */
public class FlowNodeExtendConfig extends FlowNodeConfig {

    public FlowNodeExtendConfig(FlowNodeConfig config) {
        setId(config.getId());
        setType(config.getType());
        setTitle(config.getTitle());
        setMethod(config.getMethod());
        setReference(config.getReference());
        setParams(config.getParams());
        setResults(config.getResults());
        setAsync(config.getAsync());
        setSchedule(config.getSchedule());
    }

}
