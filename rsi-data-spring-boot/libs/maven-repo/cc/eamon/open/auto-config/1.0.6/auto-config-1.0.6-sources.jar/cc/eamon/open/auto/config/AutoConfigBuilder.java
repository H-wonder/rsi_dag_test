package cc.eamon.open.auto.config;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-09-08 15:52:18
 */
public interface AutoConfigBuilder {

    Object build();

    void validate();

}
