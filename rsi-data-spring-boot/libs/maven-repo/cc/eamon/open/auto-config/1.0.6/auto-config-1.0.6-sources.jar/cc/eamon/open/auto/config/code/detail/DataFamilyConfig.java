package cc.eamon.open.auto.config.code.detail;

import java.util.List;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2023-08-03 02:21:48
 */
public abstract class DataFamilyConfig extends FamilyConfig {

    protected List<ModelConfig> models;

    protected List<RelationConfig> relations;

    public List<ModelConfig> getModels() {
        return models;
    }

    public void setModels(List<ModelConfig> models) {
        this.models = models;
    }

    public List<RelationConfig> getRelations() {
        return relations;
    }

    public void setRelations(List<RelationConfig> relations) {
        this.relations = relations;
    }
}
