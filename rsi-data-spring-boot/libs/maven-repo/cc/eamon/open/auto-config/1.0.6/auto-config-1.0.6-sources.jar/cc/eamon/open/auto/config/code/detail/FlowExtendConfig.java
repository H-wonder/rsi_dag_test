package cc.eamon.open.auto.config.code.detail;

import cc.eamon.open.flow.config.flow.FlowConfig;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2023-09-14 17:35:59
 */
public class FlowExtendConfig extends FlowConfig {

    private Boolean ifOpen = false;

    public FlowExtendConfig() {
    }

    public FlowExtendConfig(FlowConfig config, Boolean ifOpen) {
        setId(config.getId());
        setType(config.getType());
        setTitle(config.getTitle());
        setParams(config.getParams());
        setResults(config.getResults());
        setNodes(config.getNodes());
        setRoutes(config.getRoutes());
        setStrategies(config.getStrategies());
        setSchedule(config.getSchedule());
        setIfOpen(ifOpen);
    }

    public Boolean getIfOpen() {
        return ifOpen;
    }

    public void setIfOpen(Boolean ifOpen) {
        this.ifOpen = ifOpen;
    }
}
