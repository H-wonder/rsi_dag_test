package cc.eamon.open.auto.config.app.builder;

import cc.eamon.open.auto.config.AutoConfigBuilder;
import cc.eamon.open.auto.config.app.detail.DatabaseAppConfig;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-09-06 15:52:20
 */
public class DatabaseAppConfigBuilder implements AutoConfigBuilder {

    private String id;

    private boolean build;

    private boolean deploy;

    private boolean run;

    private String name;

    private String type = "MYSQL";

    private String host;

    private String port;

    private String username;

    private String password;

    private String schema;

    private String encoding = "utf8";


    @Override
    public DatabaseAppConfig build() {
        validate();
        return new DatabaseAppConfig(id, build, deploy, run, name, type, host, port, username, password, schema, encoding);
    }

    @Override
    public void validate() {

    }

    public DatabaseAppConfigBuilder setId(String id) {
        this.id = id;
        return this;
    }

    public DatabaseAppConfigBuilder setBuild(boolean build) {
        this.build = build;
        return this;
    }

    public DatabaseAppConfigBuilder setDeploy(boolean deploy) {
        this.deploy = deploy;
        return this;
    }

    public DatabaseAppConfigBuilder setRun(boolean run) {
        this.run = run;
        return this;
    }

    public DatabaseAppConfigBuilder addName(String name) {
        this.name = name;
        return this;
    }

    public DatabaseAppConfigBuilder addType(String type) {
        this.type = type;
        return this;
    }

    public DatabaseAppConfigBuilder addHost(String host) {
        this.host = host;
        return this;
    }

    public DatabaseAppConfigBuilder addPort(String port) {
        this.port = port;
        return this;
    }

    public DatabaseAppConfigBuilder addUsername(String username) {
        this.username = username;
        return this;
    }

    public DatabaseAppConfigBuilder addPassword(String password) {
        this.password = password;
        return this;
    }

    public DatabaseAppConfigBuilder addSchema(String schema) {
        this.schema = schema;
        return this;
    }

    public DatabaseAppConfigBuilder addEncoding(String encoding) {
        this.encoding = encoding;
        return this;
    }

    public String getId() {
        return id;
    }

    public boolean isBuild() {
        return build;
    }

    public boolean isDeploy() {
        return deploy;
    }

    public boolean isRun() {
        return run;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public String getHost() {
        return host;
    }

    public String getPort() {
        return port;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getSchema() {
        return schema;
    }

    public String getEncoding() {
        return encoding;
    }
}
