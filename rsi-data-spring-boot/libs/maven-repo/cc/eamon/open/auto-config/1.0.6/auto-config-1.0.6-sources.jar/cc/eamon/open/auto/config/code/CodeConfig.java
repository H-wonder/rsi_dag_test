package cc.eamon.open.auto.config.code;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-02-22 04:04:19
 */
public interface CodeConfig {

}
