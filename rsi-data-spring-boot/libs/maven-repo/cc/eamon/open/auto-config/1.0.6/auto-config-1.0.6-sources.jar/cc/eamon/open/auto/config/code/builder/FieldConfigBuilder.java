package cc.eamon.open.auto.config.code.builder;

import cc.eamon.open.auto.config.AutoConfigBuilder;
import cc.eamon.open.auto.config.code.detail.FieldConfig;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-09-08 16:01:22
 */
public class FieldConfigBuilder implements AutoConfigBuilder {

    private FieldConfig fieldConfig;

    public FieldConfigBuilder() {
    }

    public FieldConfigBuilder(FieldConfig fieldConfig) {
        this.fieldConfig = fieldConfig;
    }

    @Override
    public FieldConfig build() {
        validate();
        return fieldConfig;
    }

    @Override
    public void validate() {
        if (StringUtils.isEmpty(getNotes())) {
            setNotes(getFieldTitle());
        }
        // TODO: NEED REFACTOR
        switch (getName()){
            case "id":
                setLength("32");
                break;
            case "gmtUpdate":
                setExtra("ON UPDATE current_timestamp()");
            case "gmtCreate":
                setType("Date");
                setLength("0");
                setNotnull(true);
                setEditable(false);
                setDefaultValue("current_timestamp()");
                setFilterType("between");
                break;
        }

        Assert.notNull(fieldConfig, "field config null");
        Assert.notNull(fieldConfig.getName(), "field name null");
        Assert.notNull(fieldConfig.getType(), "field type null");
        Assert.notNull(fieldConfig.getLength(), "field length null");
        Assert.notNull(fieldConfig.getNotes(), "field notes null");
        Assert.notNull(fieldConfig.getFieldTitle(), "field title null");

    }

    public String getName() {
        return fieldConfig.getName();
    }

    public void setName(String name) {
        fieldConfig.setName(name);
    }

    public String getType() {
        return fieldConfig.getType();
    }

    public void setType(String type) {
        fieldConfig.setType(type);
    }

    public String getLength() {
        return fieldConfig.getLength();
    }

    public void setLength(String length) {
        fieldConfig.setLength(length);
    }

    public String getNotes() {
        return fieldConfig.getNotes();
    }

    public void setNotes(String notes) {
        fieldConfig.setNotes(notes);
    }

    public String getFieldTitle() {
        return fieldConfig.getFieldTitle();
    }

    public void setFieldTitle(String fieldTitle) {
        fieldConfig.setFieldTitle(fieldTitle);
    }

    public boolean isNotnull() {
        return fieldConfig.isNotnull();
    }

    public void setNotnull(boolean notnull) {
        fieldConfig.setNotnull(notnull);
    }

    public boolean isEditable() {
        return fieldConfig.isEditable();
    }

    public void setEditable(boolean editable) {
        fieldConfig.setEditable(editable);
    }

    public List<String> getUniqueNames() {
        return fieldConfig.getUniqueNames();
    }

    public void setUniqueNames(List<String> uniqueNames) {
        fieldConfig.setUniqueNames(uniqueNames);
    }

    public String getFilterType() {
        return fieldConfig.getFilterType();
    }

    public void setFilterType(String filterType) {
        fieldConfig.setFilterType(filterType);
    }

    public List<String> getFilterTypes() {
        return fieldConfig.getFilterTypes();
    }

    public void setFilterTypes(List<String> filterTypes) {
        fieldConfig.setFilterTypes(filterTypes);
    }

    public String getPattern() {
        return fieldConfig.getPattern();
    }

    public void setPattern(String pattern) {
        fieldConfig.setPattern(pattern);
    }

    public String getDefaultValue() {
        return fieldConfig.getDefaultValue();
    }

    public void setDefaultValue(String defaultValue) {
        fieldConfig.setDefaultValue(defaultValue);
    }

    public String getExtra() {
        return fieldConfig.getExtra();
    }

    public void setExtra(String extra) {
        fieldConfig.setExtra(extra);
    }

}
