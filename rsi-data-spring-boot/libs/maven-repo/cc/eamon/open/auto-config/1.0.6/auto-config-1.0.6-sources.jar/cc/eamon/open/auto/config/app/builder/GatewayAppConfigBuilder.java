package cc.eamon.open.auto.config.app.builder;

import cc.eamon.open.auto.config.AutoConfigBuilder;
import cc.eamon.open.auto.config.app.detail.GatewayAppConfig;
import cc.eamon.open.auto.config.app.detail.env.EnvConfig;

import java.util.ArrayList;
import java.util.List;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-09-06 15:24:29
 */
public class GatewayAppConfigBuilder implements AutoConfigBuilder {

    private String id;

    private boolean build;

    private boolean deploy;

    private boolean run;

    private String location;

    private String groupId;

    private String artifactId;

    private String version;

    private String port;

    private String name;

    private String description;

    private List<EnvConfig> centerIds = new ArrayList<>();

    public GatewayAppConfigBuilder() {
    }

    public GatewayAppConfigBuilder(String id, boolean build, boolean deploy, boolean run, String location, String groupId, String artifactId, String version, String port, String name, String description, List<EnvConfig> centerIds) {
        this.id = id;
        this.build = build;
        this.deploy = deploy;
        this.run = run;
        this.location = location;
        this.groupId = groupId;
        this.artifactId = artifactId;
        this.version = version;
        this.port = port;
        this.name = name;
        this.description = description;
        this.centerIds = centerIds;
    }


    @Override
    public GatewayAppConfig build() {
        validate();
        return new GatewayAppConfig(id, build, deploy, run, location, groupId, artifactId, version, port, name, description, centerIds);
    }

    @Override
    public void validate() {

    }

    public GatewayAppConfigBuilder setId(String id) {
        this.id = id;
        return this;
    }

    public GatewayAppConfigBuilder setBuild(boolean build) {
        this.build = build;
        return this;
    }

    public GatewayAppConfigBuilder setDeploy(boolean deploy) {
        this.deploy = deploy;
        return this;
    }

    public GatewayAppConfigBuilder setRun(boolean run) {
        this.run = run;
        return this;
    }

    public GatewayAppConfigBuilder addLocation(String location) {
        this.location = location;
        return this;
    }

    public GatewayAppConfigBuilder addGroupId(String groupId) {
        this.groupId = groupId;
        return this;
    }

    public GatewayAppConfigBuilder addArtifactId(String artifactId) {
        this.artifactId = artifactId;
        return this;
    }

    public GatewayAppConfigBuilder addVersion(String version) {
        this.version = version;
        return this;
    }

    public GatewayAppConfigBuilder addPort(String port) {
        this.port = port;
        return this;
    }

    public GatewayAppConfigBuilder addName(String name) {
        this.name = name;
        return this;
    }

    public GatewayAppConfigBuilder addDescription(String description) {
        this.description = description;
        return this;
    }

    public GatewayAppConfigBuilder addCenter(String env, CenterAppConfigBuilder center) {
        centerIds.add(new EnvConfig(env, center.getId()));
        return this;
    }

    public String getId() {
        return id;
    }

    public boolean isBuild() {
        return build;
    }

    public boolean isDeploy() {
        return deploy;
    }

    public boolean isRun() {
        return run;
    }

    public String getLocation() {
        return location;
    }

    public String getGroupId() {
        return groupId;
    }

    public String getArtifactId() {
        return artifactId;
    }

    public String getVersion() {
        return version;
    }

    public String getPort() {
        return port;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public List<EnvConfig> getCenterIds() {
        return centerIds;
    }
}
