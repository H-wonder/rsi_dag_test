package cc.eamon.open.auto.config.app.newbuilder;

import cc.eamon.open.auto.config.AutoConfigBuilder;
import cc.eamon.open.auto.config.app.ApplicationServiceConfigTemplate;
import cc.eamon.open.auto.config.app.detail.CenterAppConfig;
import cc.eamon.open.auto.config.app.detail.DatabaseAppConfig;
import cc.eamon.open.auto.config.app.detail.GatewayAppConfig;
import cc.eamon.open.auto.config.app.detail.ServiceAppConfig;
import com.alibaba.fastjson.JSONObject;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.List;

/**
 * @author lzr
 * @date 2021/1/28 23:39
 */
public class ApplicationServiceConfigTemplateBuilder implements AutoConfigBuilder {

    private String id;

    private boolean build;

    private boolean deploy;

    private boolean run;

    private final List<CenterAppConfigBuilder> centers = new ArrayList<>();

    private final List<GatewayAppConfigBuilder> gateways = new ArrayList<>();

    private final List<ServiceAppConfigBuilder> services = new ArrayList<>();

    private final List<DatabaseAppConfigBuilder> databases = new ArrayList<>();

    public ApplicationServiceConfigTemplateBuilder(){}

    public ApplicationServiceConfigTemplateBuilder(String jsonConfigString){
        ApplicationServiceConfigTemplate applicationServiceConfigTemplate = JSONObject.parseObject(jsonConfigString, ApplicationServiceConfigTemplate.class);
        this.id = applicationServiceConfigTemplate.getId();
        this.build = applicationServiceConfigTemplate.isBuild();
        this.deploy = applicationServiceConfigTemplate.isDeploy();
        this.run = applicationServiceConfigTemplate.isRun();
        for(CenterAppConfig centerAppConfig : applicationServiceConfigTemplate.getCenters()){
            this.centers.add(new CenterAppConfigBuilder(centerAppConfig));
        }

        for(GatewayAppConfig gatewayAppConfig : applicationServiceConfigTemplate.getGateways()){
            this.gateways.add(new GatewayAppConfigBuilder(gatewayAppConfig));
        }

        for(ServiceAppConfig serviceAppConfig : applicationServiceConfigTemplate.getServices()){
            this.services.add(new ServiceAppConfigBuilder(serviceAppConfig));
        }

        for(DatabaseAppConfig databaseAppConfig : applicationServiceConfigTemplate.getDatabases()){
            this.databases.add(new DatabaseAppConfigBuilder(databaseAppConfig));
        }

    }

    @Override
    public ApplicationServiceConfigTemplate build() {
        List<CenterAppConfig> centers = new ArrayList<>();
        List<GatewayAppConfig> gateways = new ArrayList<>();
        List<ServiceAppConfig> services = new ArrayList<>();
        List<DatabaseAppConfig> databases = new ArrayList<>();
        for(CenterAppConfigBuilder centerAppConfigBuilder : this.centers){
            centers.add(centerAppConfigBuilder.build());
        }
        for(GatewayAppConfigBuilder gatewayAppConfigBuilder : this.gateways){
            gateways.add(gatewayAppConfigBuilder.build());
        }
        for(ServiceAppConfigBuilder serviceAppConfigBuilder : this.services){
            services.add(serviceAppConfigBuilder.build());
        }
        for(DatabaseAppConfigBuilder databaseAppConfigBuilder : this.databases){
            databases.add(databaseAppConfigBuilder.build());
        }
        validate(); //validate放在builder转换前做判断应该更合适
        return new ApplicationServiceConfigTemplate(id, build, deploy, run, centers, gateways, services, databases);
    }

    @Override
    public void validate() {
        Assert.notEmpty(this.centers, "centers can't be null");
        Assert.notEmpty(this.gateways, "gateways can't be null");
        Assert.notEmpty(this.databases, "databases can't be null");
        Assert.notEmpty(this.services, "services can't be null");
    }
}
