package cc.eamon.open.auto.config.app.newbuilder;

import cc.eamon.open.auto.config.AutoConfigBuilder;
import cc.eamon.open.auto.config.app.detail.GatewayAppConfig;
import cc.eamon.open.auto.config.app.detail.env.EnvConfig;
import org.springframework.util.Assert;

import java.util.*;

/**
 * @author lzr
 * @date 2021/1/28 23:04
 */
public class GatewayAppConfigBuilder implements AutoConfigBuilder {

    private final GatewayAppConfig gatewayAppConfig;

    private final List<EnvConfigBuilder> centerIds = new ArrayList<>();

    public GatewayAppConfigBuilder(GatewayAppConfig gatewayAppConfig){
        this.gatewayAppConfig = gatewayAppConfig;
        for(EnvConfig envConfig : this.gatewayAppConfig.getCenterIds()){
            centerIds.add(new EnvConfigBuilder(envConfig));
        }
    }


    @Override
    public GatewayAppConfig build() {
        List<EnvConfig> envConfigs = new ArrayList<>();
        for(EnvConfigBuilder builder : centerIds){
            envConfigs.add(builder.build());
        }
        gatewayAppConfig.setCenterIds(envConfigs);
        validate();
        return gatewayAppConfig;
    }

    @Override
    public void validate() {
        Assert.notNull(gatewayAppConfig, "gatewayApp config null");
        Assert.notNull(gatewayAppConfig.getId(), "gatewayApp id null");
        Assert.notNull(gatewayAppConfig.getLocation(), "gatewayApp location null");
        Assert.notNull(gatewayAppConfig.getGroupId(), "gatewayApp groupId null");
        Assert.notNull(gatewayAppConfig.getArtifactId(), "gatewayApp artifactId null");
        Assert.notNull(gatewayAppConfig.getVersion(), "gatewayApp version null");
        Assert.notNull(gatewayAppConfig.getPort(), "gatewayApp port null");
        Assert.notNull(gatewayAppConfig.getName(), "gatewayApp name null");
        Assert.notNull(gatewayAppConfig.getDescription(), "gatewayApp description null");
        Assert.notNull(gatewayAppConfig.getCenterIds(), "gatewayApp centerIds null");
    }

    public String getName(){
        return gatewayAppConfig.getName();
    }

    public void setName(String name){
        gatewayAppConfig.setName(name);
    }

    public String getDescription(){
        return gatewayAppConfig.getDescription();
    }

    public void setDescription(String description){
        gatewayAppConfig.setDescription(description);
    }

    public String getVersion(){
        return gatewayAppConfig.getVersion();
    }

    public void setVersion(String version){
        gatewayAppConfig.setVersion(version);
    }

    public String getPort(){
        return gatewayAppConfig.getPort();
    }

    public void setPort(String port){
        gatewayAppConfig.setPort(port);
    }

    public String getGroupId(){
        return gatewayAppConfig.getGroupId();
    }

    public void setGroupId(String groupId){
        gatewayAppConfig.setGroupId(groupId);
    }

    public String getArtifactId(){
        return gatewayAppConfig.getArtifactId();
    }

    public void setArtifactId(String artifactId){
        gatewayAppConfig.setArtifactId(artifactId);
    }

    public String getId(){
        return gatewayAppConfig.getId();
    }

    public void setId(String id){
        gatewayAppConfig.setId(id);
    }

    public String getLocation(){
        return gatewayAppConfig.getLocation();
    }

    public void setLocation(String location){
        gatewayAppConfig.setLocation(location);
    }

    public boolean isBuild(){
        return gatewayAppConfig.isBuild();
    }

    public void setBuild(boolean build){
        gatewayAppConfig.setBuild(build);
    }

    public boolean isDeploy(){
        return gatewayAppConfig.isDeploy();
    }

    public void setDeploy(boolean deploy){
        gatewayAppConfig.setDeploy(deploy);
    }

    public boolean isRun(){
        return gatewayAppConfig.isRun();
    }

    public void setRun(boolean run){
        gatewayAppConfig.setRun(run);
    }

    public List<EnvConfig> getCenterIds(){
        return gatewayAppConfig.getCenterIds();
    }

    public void setCenterIds(List<EnvConfig> centerIds){
        gatewayAppConfig.setCenterIds(centerIds);
    }
}
