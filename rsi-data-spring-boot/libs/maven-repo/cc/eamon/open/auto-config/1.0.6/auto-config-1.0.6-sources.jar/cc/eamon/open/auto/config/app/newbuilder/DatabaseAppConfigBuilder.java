package cc.eamon.open.auto.config.app.newbuilder;

import cc.eamon.open.auto.config.AutoConfigBuilder;
import cc.eamon.open.auto.config.app.detail.DatabaseAppConfig;
import org.springframework.util.Assert;

/**
 * @author lzr
 * @date 2021/1/28 22:25
 */
public class DatabaseAppConfigBuilder implements AutoConfigBuilder {

    private final DatabaseAppConfig databaseAppConfig;

    public DatabaseAppConfigBuilder(DatabaseAppConfig databaseAppConfig){
        this.databaseAppConfig = databaseAppConfig;
    }


    @Override
    public DatabaseAppConfig build() {
        validate();
        return databaseAppConfig;
    }

    @Override
    public void validate() {
        Assert.notNull(databaseAppConfig, "databaseApp config null");
        Assert.notNull(databaseAppConfig.getId(), "databaseApp id null");
        Assert.notNull(databaseAppConfig.getName(), "databaseApp name null");
        Assert.notNull(databaseAppConfig.getType(), "databaseApp type null");
        Assert.notNull(databaseAppConfig.getHost(), "databaseApp host null");
        Assert.notNull(databaseAppConfig.getPort(), "databaseApp port null");
        Assert.notNull(databaseAppConfig.getUsername(), "databaseApp username null");
        Assert.notNull(databaseAppConfig.getPassword(), "databaseApp password null");
        Assert.notNull(databaseAppConfig.getSchema(), "databaseApp schema null");
        Assert.notNull(databaseAppConfig.getEncoding(), "databaseApp encoding null");
    }

    public boolean isDeploy(){
        return databaseAppConfig.isDeploy();
    }

    public void setDeploy(boolean deploy){
        databaseAppConfig.setDeploy(deploy);
    }

    public boolean isRun(){
        return databaseAppConfig.isRun();
    }

    public void setRun(boolean run){
        databaseAppConfig.setRun(run);
    }

    public boolean isBuild(){
        return databaseAppConfig.isBuild();
    }

    public void setBuild(boolean build){
        databaseAppConfig.setBuild(build);
    }

    public String getEncoding(){
        return databaseAppConfig.getEncoding();
    }

    public void setEncoding(String encoding){
        databaseAppConfig.setEncoding(encoding);
    }

    public String getSchema(){
        return databaseAppConfig.getSchema();
    }

    public void setSchema(String schema){
        databaseAppConfig.setSchema(schema);
    }

    public String getPassword(){
        return databaseAppConfig.getPassword();
    }

    public void setPassword(String password){
        databaseAppConfig.setPassword(password);
    }

    public String getUsername(){
        return databaseAppConfig.getUsername();
    }

    public void setUsername(String username){
        databaseAppConfig.setUsername(username);
    }

    public String getPort(){
        return databaseAppConfig.getPort();
    }

    public void setPort(String port){
        databaseAppConfig.setPort(port);
    }

    public String getHost(){
        return databaseAppConfig.getHost();
    }

    public void setHost(String host){
        databaseAppConfig.setHost(host);
    }

    public String getType(){
        return databaseAppConfig.getType();
    }

    public void setType(String type){
        databaseAppConfig.setType(type);
    }

    public String getName(){
        return databaseAppConfig.getName();
    }

    public void setName(String name){
        databaseAppConfig.setName(name);
    }

    public String getId(){
        return databaseAppConfig.getId();
    }

    public void setId(String id){
        databaseAppConfig.setId(id);
    }
}
