package cc.eamon.open.auto.config.code.detail;

import cc.eamon.open.auto.config.code.CodeConfig;

import java.util.List;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-02-22 04:05:53
 */
public class RelationConfig implements CodeConfig {

    private String id;

    private String modelMainId;

    private List<String> modelMainKey;

    private String modelRelatedId;

    private List<String> modelRelatedKey;

    private String relationType;

    private String relationName;

    private String relationTitle;

    private Boolean atLeastOne = false;

//    @Override
//    public boolean equals(Object o) {
//        if (this == o) return true;
//        if (o == null || getClass() != o.getClass()) return false;
//        RelationConfig that = (RelationConfig) o;
//        boolean equalStatus = Objects.equals(id, that.id) &&
//                Objects.equals(modelMainId, that.modelMainId) &&
//                Objects.equals(modelRelatedId, that.modelRelatedId) &&
//                Objects.equals(relationType, that.relationType) &&
//                Objects.equals(relationName, that.relationName) &&
//                Objects.equals(relationTitle, that.relationTitle);
//
//
//        for (String key : modelMainKey) {
//            boolean status = false;
//            for (String thatKey : that.modelMainKey) {
//                if (Objects.equals(key, thatKey)) {
//                    status = true;
//                    break;
//                }
//            }
//            equalStatus = equalStatus & status;
//        }
//
//        for (String key : modelRelatedKey) {
//            boolean status = false;
//            for (String thatKey : that.modelRelatedKey) {
//                if (Objects.equals(key, thatKey)) {
//                    status = true;
//                    break;
//                }
//            }
//            equalStatus = equalStatus & status;
//        }
//
//        return equalStatus;
//
//    }
//
//    @Override
//    public int hashCode() {
//        return Objects.hash(id, modelMainId, modelMainKey, modelRelatedId, modelRelatedKey, relationType, relationName, relationTitle);
//    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getModelMainId() {
        return modelMainId;
    }

    public void setModelMainId(String modelMainId) {
        this.modelMainId = modelMainId;
    }

    public List<String> getModelMainKey() {
        return modelMainKey;
    }

    public void setModelMainKey(List<String> modelMainKey) {
        this.modelMainKey = modelMainKey;
    }

    public String getModelRelatedId() {
        return modelRelatedId;
    }

    public void setModelRelatedId(String modelRelatedId) {
        this.modelRelatedId = modelRelatedId;
    }

    public List<String> getModelRelatedKey() {
        return modelRelatedKey;
    }

    public void setModelRelatedKey(List<String> modelRelatedKey) {
        this.modelRelatedKey = modelRelatedKey;
    }

    public String getRelationType() {
        return relationType;
    }

    public void setRelationType(String relationType) {
        this.relationType = relationType;
    }

    public String getRelationName() {
        return relationName;
    }

    public void setRelationName(String relationName) {
        this.relationName = relationName;
    }

    public String getRelationTitle() {
        return relationTitle;
    }

    public void setRelationTitle(String relationTitle) {
        this.relationTitle = relationTitle;
    }

    public Boolean getAtLeastOne() {
        return atLeastOne;
    }

    public void setAtLeastOne(Boolean atLeastOne) {
        this.atLeastOne = atLeastOne;
    }
}
