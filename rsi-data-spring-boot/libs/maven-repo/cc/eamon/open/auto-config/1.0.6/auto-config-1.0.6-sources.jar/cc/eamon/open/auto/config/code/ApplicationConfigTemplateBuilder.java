package cc.eamon.open.auto.config.code;

import cc.eamon.open.auto.config.AutoConfigBuilder;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-09-06 15:18:32
 */
public class ApplicationConfigTemplateBuilder implements AutoConfigBuilder {


    public ApplicationConfigTemplateBuilder() {
    }

    @Override
    public ApplicationConfigTemplate build() {
        validate();
        return new ApplicationConfigTemplate();
    }

    @Override
    public void validate() {
    }

}
