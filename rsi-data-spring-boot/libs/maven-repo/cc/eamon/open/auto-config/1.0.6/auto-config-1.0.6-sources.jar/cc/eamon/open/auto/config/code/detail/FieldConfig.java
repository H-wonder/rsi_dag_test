package cc.eamon.open.auto.config.code.detail;

import cc.eamon.open.auto.config.code.CodeConfig;

import java.util.List;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-02-23 18:01:04
 */
public class FieldConfig implements CodeConfig {

    private String name;

    private String type;

    private String length;

    private String notes;

    private String fieldTitle;

    private boolean notnull;

    private boolean editable;

    private List<String> uniqueNames;

    private String filterType;

    private List<String> filterTypes;

    private String pattern;

    private String defaultValue;

    private String extra;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLength() {
        return length;
    }

    public void setLength(String length) {
        this.length = length;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getFieldTitle() {
        return fieldTitle;
    }

    public void setFieldTitle(String fieldTitle) {
        this.fieldTitle = fieldTitle;
    }

    public boolean isNotnull() {
        return notnull;
    }

    public void setNotnull(boolean notnull) {
        this.notnull = notnull;
    }

    public boolean isEditable() {
        return editable;
    }

    public void setEditable(boolean editable) {
        this.editable = editable;
    }

    public List<String> getUniqueNames() {
        return uniqueNames;
    }

    public void setUniqueNames(List<String> uniqueNames) {
        this.uniqueNames = uniqueNames;
    }

    public String getFilterType() {
        return filterType;
    }

    public void setFilterType(String filterType) {
        this.filterType = filterType;
    }

    public List<String> getFilterTypes() {
        return filterTypes;
    }

    public void setFilterTypes(List<String> filterTypes) {
        this.filterTypes = filterTypes;
    }

    public String getPattern() {
        return pattern;
    }

    public void setPattern(String pattern) {
        this.pattern = pattern;
    }

    public String getDefaultValue() {
        return defaultValue;
    }

    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }

    public String getExtra() {
        return extra;
    }

    public void setExtra(String extra) {
        this.extra = extra;
    }
}
