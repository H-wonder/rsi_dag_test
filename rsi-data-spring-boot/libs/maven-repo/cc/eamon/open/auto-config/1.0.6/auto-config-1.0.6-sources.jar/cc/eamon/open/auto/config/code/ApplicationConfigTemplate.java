package cc.eamon.open.auto.config.code;

import cc.eamon.open.auto.config.code.detail.ModelConfig;
import cc.eamon.open.auto.config.code.detail.RelationConfig;

import java.util.ArrayList;
import java.util.List;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-02-22 04:08:55
 */
public class ApplicationConfigTemplate implements CodeConfig {

    private List<ApplicationFamilyConfigTemplate> families = new ArrayList<>();

    private List<ApplicationFamilyThirdPartyConfigTemplate> thirdPartyFamilies = new ArrayList<>();

    public ApplicationConfigTemplate() {
    }


    public List<ApplicationFamilyConfigTemplate> getFamilies() {
        return families;
    }

    public void setFamilies(List<ApplicationFamilyConfigTemplate> families) {
        this.families = families;
    }

    public List<ApplicationFamilyThirdPartyConfigTemplate> getThirdPartyFamilies() {
        return thirdPartyFamilies;
    }

    public void setThirdPartyFamilies(List<ApplicationFamilyThirdPartyConfigTemplate> thirdPartyFamilies) {
        this.thirdPartyFamilies = thirdPartyFamilies;
    }

    private List<ModelConfig> models = new ArrayList<>();
    private List<RelationConfig> relations = new ArrayList<>();

    public List<ModelConfig> getModels() {
        if (!models.isEmpty()) return models;
        models = new ArrayList<>();
        for (ApplicationFamilyConfigTemplate family : getFamilies()) {
            models.addAll(family.getModels());
        }
        for (ApplicationFamilyThirdPartyConfigTemplate family : getThirdPartyFamilies()) {
            models.addAll(family.getModels());
        }
        return models;
    }

    public List<RelationConfig> getRelations() {
        if (!relations.isEmpty()) return relations;
        relations = new ArrayList<>();
        for (ApplicationFamilyConfigTemplate family : getFamilies()) {
            relations.addAll(family.getRelations());
        }
        for (ApplicationFamilyThirdPartyConfigTemplate family : getThirdPartyFamilies()) {
            relations.addAll(family.getRelations());
        }
        return relations;
    }
}
