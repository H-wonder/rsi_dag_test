package cc.eamon.open.auto.config.app.detail;

import cc.eamon.open.auto.config.app.AppConfig;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-07-07 21:53:00
 */
public interface SpringBootAppConfig extends AppConfig {

    String getLocation();

    String getGroupId();

    String getArtifactId();

    String getVersion();

    String getPort();

    String getName();

    String getDescription();

}
