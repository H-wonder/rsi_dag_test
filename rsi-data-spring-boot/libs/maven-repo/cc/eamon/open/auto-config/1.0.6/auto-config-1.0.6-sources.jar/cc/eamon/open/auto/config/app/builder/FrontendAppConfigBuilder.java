package cc.eamon.open.auto.config.app.builder;

import cc.eamon.open.auto.config.AutoConfigBuilder;
import cc.eamon.open.auto.config.app.detail.FrontendAppConfig;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-09-16 13:43:35
 */
public class FrontendAppConfigBuilder implements AutoConfigBuilder {

    private String id;

    private boolean build;

    private boolean deploy;

    private boolean run;

    private String projectTitle;

    private String projectDescription;

    private String version;

    private String name;

    private String description;

    private String location;

    private String remote;

    private String baseUrl;

    @Override
    public FrontendAppConfig build() {
        validate();
        return new FrontendAppConfig(id, build, deploy, run, projectTitle, projectDescription, version, name, description, location, remote, baseUrl);
    }

    @Override
    public void validate() {

    }

    public FrontendAppConfigBuilder setId(String id) {
        this.id = id;
        return this;
    }

    public FrontendAppConfigBuilder setBuild(boolean build) {
        this.build = build;
        return this;
    }

    public FrontendAppConfigBuilder setDeploy(boolean deploy) {
        this.deploy = deploy;
        return this;
    }

    public FrontendAppConfigBuilder setRun(boolean run) {
        this.run = run;
        return this;
    }

    public FrontendAppConfigBuilder addProjectTitle(String projectTitle) {
        this.projectTitle = projectTitle;
        return this;
    }

    public FrontendAppConfigBuilder addProjectDescription(String projectDescription) {
        this.projectDescription = projectDescription;
        return this;
    }

    public FrontendAppConfigBuilder addVersion(String version) {
        this.version = version;
        return this;
    }

    public FrontendAppConfigBuilder addName(String name) {
        this.name = name;
        return this;
    }

    public FrontendAppConfigBuilder addDescription(String description) {
        this.description = description;
        return this;
    }

    public FrontendAppConfigBuilder addLocation(String location) {
        this.location = location;
        return this;
    }

    public FrontendAppConfigBuilder addRemote(String remote) {
        this.remote = remote;
        return this;
    }

    public FrontendAppConfigBuilder addBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
        return this;
    }
}
