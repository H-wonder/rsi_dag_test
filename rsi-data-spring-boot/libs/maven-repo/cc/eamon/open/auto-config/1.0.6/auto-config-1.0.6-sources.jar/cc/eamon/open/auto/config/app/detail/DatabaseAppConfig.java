package cc.eamon.open.auto.config.app.detail;

import cc.eamon.open.auto.config.app.AppConfig;

import java.util.Objects;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-02-20 17:53:36
 */
public class DatabaseAppConfig implements AppConfig {

    private String id;

    private boolean build;

    private boolean deploy;

    private boolean run;

    private String name;

    private String type = "MySQL";

    private String host;

    private String port;

    private String username;

    private String password;

    private String schema;

    private String encoding = "utf8";

    public DatabaseAppConfig() {
    }

    public DatabaseAppConfig(String id, boolean build, boolean deploy, boolean run, String name, String type, String host, String port, String username, String password, String schema, String encoding) {
        this.id = id;
        this.build = build;
        this.deploy = deploy;
        this.run = run;
        this.name = name;
        this.type = type;
        this.host = host;
        this.port = port;
        this.username = username;
        this.password = password;
        this.schema = schema;
        this.encoding = encoding;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DatabaseAppConfig that = (DatabaseAppConfig) o;
        return build == that.build &&
                deploy == that.deploy &&
                run == that.run &&
                Objects.equals(id, that.id) &&
                Objects.equals(name, that.name) &&
                Objects.equals(type, that.type) &&
                Objects.equals(host, that.host) &&
                Objects.equals(port, that.port) &&
                Objects.equals(username, that.username) &&
                Objects.equals(password, that.password) &&
                Objects.equals(schema, that.schema) &&
                Objects.equals(encoding, that.encoding);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, build, deploy, run, name, type, host, port, username, password, schema, encoding);
    }

    @Override
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public boolean isBuild() {
        return build;
    }

    public void setBuild(boolean build) {
        this.build = build;
    }

    @Override
    public boolean isDeploy() {
        return deploy;
    }

    public void setDeploy(boolean deploy) {
        this.deploy = deploy;
    }

    @Override
    public boolean isRun() {
        return run;
    }

    public void setRun(boolean run) {
        this.run = run;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSchema() {
        return schema;
    }

    public void setSchema(String schema) {
        this.schema = schema;
    }

    public String getEncoding() {
        return encoding;
    }

    public void setEncoding(String encoding) {
        this.encoding = encoding;
    }
}
