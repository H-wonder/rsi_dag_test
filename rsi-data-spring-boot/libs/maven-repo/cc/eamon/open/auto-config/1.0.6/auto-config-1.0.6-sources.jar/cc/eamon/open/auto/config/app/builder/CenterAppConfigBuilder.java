package cc.eamon.open.auto.config.app.builder;

import cc.eamon.open.auto.config.AutoConfigBuilder;
import cc.eamon.open.auto.config.app.detail.CenterAppConfig;

/**
 * Author: eamon
 * Email: eamon@eamon.cc
 * Time: 2020-09-06 15:23:58
 */
public class CenterAppConfigBuilder implements AutoConfigBuilder {

    private String id;

    private boolean build;

    private boolean deploy;

    private boolean run;

    private String location;

    private String groupId;

    private String artifactId;

    private String version;

    private String host;

    private String port;

    private String name;

    private String description;


    @Override
    public CenterAppConfig build() {
        validate();
        return new CenterAppConfig(id, build, deploy, run, location, groupId, artifactId, version, host, port, name, description);
    }

    @Override
    public void validate() {

    }

    public CenterAppConfigBuilder setId(String id) {
        this.id = id;
        return this;
    }

    public CenterAppConfigBuilder setBuild(boolean build) {
        this.build = build;
        return this;
    }

    public CenterAppConfigBuilder setDeploy(boolean deploy) {
        this.deploy = deploy;
        return this;
    }

    public CenterAppConfigBuilder setRun(boolean run) {
        this.run = run;
        return this;
    }

    public CenterAppConfigBuilder addLocation(String location) {
        this.location = location;
        return this;
    }

    public CenterAppConfigBuilder addGroupId(String groupId) {
        this.groupId = groupId;
        return this;
    }

    public CenterAppConfigBuilder addArtifactId(String artifactId) {
        this.artifactId = artifactId;
        return this;
    }

    public CenterAppConfigBuilder addVersion(String version) {
        this.version = version;
        return this;
    }

    public CenterAppConfigBuilder addHost(String host) {
        this.host = host;
        return this;
    }

    public CenterAppConfigBuilder addPort(String port) {
        this.port = port;
        return this;
    }

    public CenterAppConfigBuilder addName(String name) {
        this.name = name;
        return this;
    }

    public CenterAppConfigBuilder addDescription(String description) {
        this.description = description;
        return this;
    }

    public String getId() {
        return id;
    }

    public boolean isBuild() {
        return build;
    }

    public boolean isDeploy() {
        return deploy;
    }

    public boolean isRun() {
        return run;
    }

    public String getLocation() {
        return location;
    }

    public String getGroupId() {
        return groupId;
    }

    public String getArtifactId() {
        return artifactId;
    }

    public String getVersion() {
        return version;
    }

    public String getHost() {
        return host;
    }

    public String getPort() {
        return port;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }
}
